<?php
// ================================================================
//  Jovern's IMS — REST API for Flutter App
//  Place this file in: /ims/api/api.php
// ================================================================
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

require_once '../config.php';

// --- Simple JWT-like token auth ---
function getToken(): ?string {
    $h = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (str_starts_with($h, 'Bearer ')) return substr($h, 7);
    return $_GET['token'] ?? null;
}
function verifyToken($conn): ?array {
    $token = getToken();
    if (!$token) return null;
    $t = mysqli_real_escape_string($conn, $token);
    $r = mysqli_fetch_assoc(mysqli_query($conn, "SELECT id,username,role FROM users WHERE session_token='$t' AND approved=1 LIMIT 1"));
    return $r ?: null;
}
function requireAuth($conn): array {
    $user = verifyToken($conn);
    if (!$user) { http_response_code(401); echo json_encode(['error'=>'Unauthorized']); exit; }
    return $user;
}
function ok($data): void  { echo json_encode(['success'=>true,'data'=>$data]); exit; }
function err($msg, $code=400): void { http_response_code($code); echo json_encode(['success'=>false,'error'=>$msg]); exit; }

// Add session_token column if not exists
mysqli_query($conn, "ALTER TABLE users ADD COLUMN IF NOT EXISTS session_token VARCHAR(64) DEFAULT NULL");

$method = $_SERVER['REQUEST_METHOD'];
$path   = trim($_GET['path'] ?? '', '/');
$parts  = explode('/', $path);
$entity = $parts[0] ?? '';
$id     = $parts[1] ?? null;
$input  = json_decode(file_get_contents('php://input'), true) ?? [];

// ================================================================
// AUTH
// ================================================================
if ($entity === 'login' && $method === 'POST') {
    $username = trim($input['username'] ?? '');
    $password = trim($input['password'] ?? '');
    if (!$username || !$password) err('Username and password required');
    $u = mysqli_real_escape_string($conn, $username);
    $row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE username='$u' AND approved=1 LIMIT 1"));
    if (!$row) err('Invalid credentials', 401);
    $valid = false;
    if (password_verify($password, $row['password'])) {
        $valid = true;
    } elseif ($row['password'] === $password) {
        // upgrade plain text to bcrypt
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $h = mysqli_real_escape_string($conn, $hash);
        mysqli_query($conn, "UPDATE users SET password='$h' WHERE id={$row['id']}");
        $valid = true;
    }
    if (!$valid) err('Invalid credentials', 401);
    $token = bin2hex(random_bytes(32));
    mysqli_query($conn, "UPDATE users SET session_token='$token' WHERE id={$row['id']}");
    ok(['token'=>$token,'role'=>$row['role'],'username'=>$row['username'],'name'=>$row['name']??$row['username']]);
}

if ($entity === 'logout' && $method === 'POST') {
    $user = requireAuth($conn);
    mysqli_query($conn, "UPDATE users SET session_token=NULL WHERE id={$user['id']}");
    ok('Logged out');
}

// ================================================================
// DASHBOARD
// ================================================================
if ($entity === 'dashboard' && $method === 'GET') {
    requireAuth($conn);
    $daily  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT IFNULL(SUM(total_price),0) a FROM sales WHERE date=CURDATE()"))['a'];
    $month  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT IFNULL(SUM(total_price),0) a FROM sales WHERE DATE_FORMAT(date,'%Y-%m')=DATE_FORMAT(CURDATE(),'%Y-%m')"))['a'];
    $total  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT IFNULL(SUM(total_price),0) a FROM sales"))['a'];
    $clients= mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) a FROM customers"))['a'];
    $orders = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) a FROM purchases WHERE status NOT IN('Delivered')"))['a'];
    $outOfStock = [];
    $r = mysqli_query($conn, "SELECT name,stock FROM products WHERE stock=0 ORDER BY name");
    while($row=mysqli_fetch_assoc($r)) $outOfStock[]=$row;
    $trend = [];
    $r2 = mysqli_query($conn, "SELECT DATE(date) d, IFNULL(SUM(total_price),0) t FROM sales WHERE date>=DATE_SUB(CURDATE(),INTERVAL 30 DAY) GROUP BY DATE(date) ORDER BY d");
    while($row=mysqli_fetch_assoc($r2)) $trend[]=$row;
    $recentOrders = [];
    $r3 = mysqli_query($conn, "SELECT pu.id,p.name pname,p.image pimg,c.customer_name,pu.quantity,pu.cost,pu.status,pu.date FROM purchases pu JOIN products p ON pu.product_id=p.id LEFT JOIN customers c ON pu.customer_id=c.id ORDER BY pu.id DESC LIMIT 8");
    while($row=mysqli_fetch_assoc($r3)) $recentOrders[]=$row;
    ok(compact('daily','month','total','clients','orders','outOfStock','trend','recentOrders'));
}

// ================================================================
// CATEGORIES
// ================================================================
if ($entity === 'categories') {
    requireAuth($conn);
    if ($method === 'GET') {
        $rows = [];
        $r = mysqli_query($conn, "SELECT c.*, GROUP_CONCAT(m.material_name ORDER BY m.material_name SEPARATOR ', ') mats FROM categories c LEFT JOIN category_materials cm ON cm.category_id=c.id LEFT JOIN materials m ON m.material_id=cm.material_id GROUP BY c.id ORDER BY c.category_name");
        while($row=mysqli_fetch_assoc($r)) $rows[]=$row;
        ok($rows);
    }
    if ($method === 'POST') {
        $name = trim($input['category_name'] ?? '');
        if (!$name) err('Category name required');
        $n = mysqli_real_escape_string($conn, $name);
        mysqli_query($conn, "INSERT INTO categories(category_name)VALUES('$n')");
        $cid = mysqli_insert_id($conn);
        foreach ($input['mats'] ?? [] as $mat) {
            $mid=(int)$mat['material_id']; $qty=max(1,(int)($mat['qty']??1));
            mysqli_query($conn, "INSERT IGNORE INTO category_materials(category_id,material_id,default_qty)VALUES($cid,$mid,$qty)");
        }
        ok(['id'=>$cid]);
    }
    if ($method === 'PUT' && $id) {
        $name = trim($input['category_name'] ?? '');
        if (!$name) err('Category name required');
        $n = mysqli_real_escape_string($conn, $name);
        mysqli_query($conn, "UPDATE categories SET category_name='$n' WHERE id=$id");
        mysqli_query($conn, "DELETE FROM category_materials WHERE category_id=$id");
        foreach ($input['mats'] ?? [] as $mat) {
            $mid=(int)$mat['material_id']; $qty=max(1,(int)($mat['qty']??1));
            mysqli_query($conn, "INSERT IGNORE INTO category_materials(category_id,material_id,default_qty)VALUES($id,$mid,$qty)");
        }
        ok('Updated');
    }
    if ($method === 'DELETE' && $id) {
        mysqli_query($conn, "DELETE FROM category_materials WHERE category_id=$id");
        mysqli_query($conn, "DELETE FROM categories WHERE id=$id");
        ok('Deleted');
    }
}

// ================================================================
// MATERIALS
// ================================================================
if ($entity === 'materials') {
    requireAuth($conn);
    if ($method === 'GET') {
        $rows = [];
        $r = mysqli_query($conn, "SELECT * FROM materials ORDER BY material_name");
        while($row=mysqli_fetch_assoc($r)) $rows[]=$row;
        ok($rows);
    }
    if ($method === 'POST') {
        $n=mysqli_real_escape_string($conn,$input['material_name']??'');
        $s=mysqli_real_escape_string($conn,$input['supplier']??'');
        $p=max(0,(float)($input['price']??0));
        $img=mysqli_real_escape_string($conn,$input['image']??'');
        mysqli_query($conn,"INSERT INTO materials(material_name,supplier,price,image)VALUES('$n','$s',$p,'$img')");
        ok(['id'=>mysqli_insert_id($conn)]);
    }
    if ($method === 'PUT' && $id) {
        $n=mysqli_real_escape_string($conn,$input['material_name']??'');
        $s=mysqli_real_escape_string($conn,$input['supplier']??'');
        $p=max(0,(float)($input['price']??0));
        mysqli_query($conn,"UPDATE materials SET material_name='$n',supplier='$s',price=$p WHERE material_id=$id");
        ok('Updated');
    }
    if ($method === 'DELETE' && $id) {
        $c=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) t FROM product_materials WHERE material_id=$id"))['t'];
        if($c>0) err('Material is in use by equipment');
        mysqli_query($conn,"DELETE FROM materials WHERE material_id=$id");
        ok('Deleted');
    }
}

// ================================================================
// PRODUCTS (Equipment)
// ================================================================
if ($entity === 'products') {
    requireAuth($conn);
    if ($method === 'GET') {
        if ($id) {
            $row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT p.*,c.category_name FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.id=$id"));
            if (!$row) err('Not found', 404);
            $mats = [];
            $r = mysqli_query($conn, "SELECT m.*,pm.qty FROM product_materials pm JOIN materials m ON m.material_id=pm.material_id WHERE pm.product_id=$id");
            while($mr=mysqli_fetch_assoc($r)) $mats[]=$mr;
            $row['materials'] = $mats;
            ok($row);
        }
        $rows = [];
        $r = mysqli_query($conn, "SELECT p.*,c.category_name FROM products p LEFT JOIN categories c ON c.id=p.category_id ORDER BY p.id DESC");
        while($row=mysqli_fetch_assoc($r)){
            $mats=[];
            $mr=mysqli_query($conn,"SELECT m.material_name,pm.qty FROM product_materials pm JOIN materials m ON m.material_id=pm.material_id WHERE pm.product_id={$row['id']}");
            while($m=mysqli_fetch_assoc($mr)) $mats[]=$m;
            $row['materials']=$mats;
            $rows[]=$row;
        }
        ok($rows);
    }
    if ($method === 'POST') {
        $n=mysqli_real_escape_string($conn,$input['name']??'');
        $cid=(int)($input['category_id']??0);
        $stk=(int)($input['stock']??0);
        $lc=(float)($input['labor_cost']??0);
        $img=mysqli_real_escape_string($conn,$input['image']??'');
        $mc=0;
        foreach($input['mats']??[] as $m){
            $mid=(int)$m['material_id']; $qty=max(1,(int)($m['qty']??1));
            $pr=mysqli_fetch_assoc(mysqli_query($conn,"SELECT price FROM materials WHERE material_id=$mid"));
            if($pr) $mc+=$pr['price']*$qty;
        }
        $fp=($mc+$lc)*1.5;
        mysqli_query($conn,"INSERT INTO products(name,category_id,price,stock,labor_cost,material_cost,image)VALUES('$n',$cid,$fp,$stk,$lc,$mc,'$img')");
        $pid=mysqli_insert_id($conn);
        foreach($input['mats']??[] as $m){
            $mid=(int)$m['material_id']; $qty=max(1,(int)($m['qty']??1));
            mysqli_query($conn,"INSERT INTO product_materials(product_id,material_id,qty)VALUES($pid,$mid,$qty)");
        }
        ok(['id'=>$pid,'price'=>$fp]);
    }
    if ($method === 'PUT' && $id) {
        $n=mysqli_real_escape_string($conn,$input['name']??'');
        $cid=(int)($input['category_id']??0);
        $stk=(int)($input['stock']??0);
        $lc=(float)($input['labor_cost']??0);
        $img=mysqli_real_escape_string($conn,$input['image']??'');
        $mc=0;
        mysqli_query($conn,"DELETE FROM product_materials WHERE product_id=$id");
        foreach($input['mats']??[] as $m){
            $mid=(int)$m['material_id']; $qty=max(1,(int)($m['qty']??1));
            $pr=mysqli_fetch_assoc(mysqli_query($conn,"SELECT price FROM materials WHERE material_id=$mid"));
            if($pr) $mc+=$pr['price']*$qty;
            mysqli_query($conn,"INSERT INTO product_materials(product_id,material_id,qty)VALUES($id,$mid,$qty)");
        }
        $fp=($mc+$lc)*1.5;
        mysqli_query($conn,"UPDATE products SET name='$n',category_id=$cid,price=$fp,stock=$stk,labor_cost=$lc,material_cost=$mc,image='$img' WHERE id=$id");
        ok(['price'=>$fp]);
    }
    if ($method === 'DELETE' && $id) {
        mysqli_query($conn,"DELETE FROM product_materials WHERE product_id=$id");
        mysqli_query($conn,"DELETE FROM products WHERE id=$id");
        ok('Deleted');
    }
}

// ================================================================
// CUSTOMERS
// ================================================================
if ($entity === 'customers') {
    requireAuth($conn);
    if ($method === 'GET') {
        $rows=[];
        $r=mysqli_query($conn,"SELECT * FROM customers ORDER BY customer_name");
        while($row=mysqli_fetch_assoc($r)) $rows[]=$row;
        ok($rows);
    }
    if ($method === 'POST') {
        $n=mysqli_real_escape_string($conn,$input['customer_name']??'');
        $c=mysqli_real_escape_string($conn,$input['contact']??'');
        $em=mysqli_real_escape_string($conn,$input['email']??'');
        $ad=mysqli_real_escape_string($conn,$input['address']??'');
        $ct=mysqli_real_escape_string($conn,$input['client_type']??'Walk-in');
        $pt=mysqli_real_escape_string($conn,$input['payment_terms']??'COD');
        mysqli_query($conn,"INSERT INTO customers(customer_name,contact,email,address,client_type,payment_terms)VALUES('$n','$c','$em','$ad','$ct','$pt')");
        ok(['id'=>mysqli_insert_id($conn)]);
    }
    if ($method === 'PUT' && $id) {
        $n=mysqli_real_escape_string($conn,$input['customer_name']??'');
        $c=mysqli_real_escape_string($conn,$input['contact']??'');
        $em=mysqli_real_escape_string($conn,$input['email']??'');
        $ad=mysqli_real_escape_string($conn,$input['address']??'');
        $ct=mysqli_real_escape_string($conn,$input['client_type']??'Walk-in');
        $pt=mysqli_real_escape_string($conn,$input['payment_terms']??'COD');
        mysqli_query($conn,"UPDATE customers SET customer_name='$n',contact='$c',email='$em',address='$ad',client_type='$ct',payment_terms='$pt' WHERE id=$id");
        ok('Updated');
    }
    if ($method === 'DELETE' && $id) {
        mysqli_query($conn,"DELETE FROM customers WHERE id=$id");
        ok('Deleted');
    }
}

// ================================================================
// PURCHASES (Orders)
// ================================================================
if ($entity === 'purchases') {
    requireAuth($conn);
    if ($method === 'GET') {
        $status = $_GET['status'] ?? null;
        $where = $status ? "WHERE pu.status='".mysqli_real_escape_string($conn,$status)."'" : "WHERE pu.status NOT IN('Delivered')";
        if (isset($_GET['all'])) $where = '';
        $rows=[];
        $r=mysqli_query($conn,"SELECT pu.*,p.name pname,p.image pimg,c.customer_name FROM purchases pu JOIN products p ON pu.product_id=p.id LEFT JOIN customers c ON pu.customer_id=c.id $where ORDER BY pu.id DESC");
        while($row=mysqli_fetch_assoc($r)) $rows[]=$row;
        ok($rows);
    }
    if ($method === 'POST') {
        $pid=(int)($input['product_id']??0);
        $cid=$input['customer_id']??(int)($input['customer_id']??0);
        $cid=$cid?$cid:'NULL';
        $qty=(int)($input['quantity']??1);
        $disc=(float)($input['discount']??0);
        $notes=mysqli_real_escape_string($conn,$input['notes']??'');
        $dt=mysqli_real_escape_string($conn,$input['date']??date('Y-m-d'));
        $createdBy=mysqli_real_escape_string($conn,$input['created_by']??'app');
        $prod=mysqli_fetch_assoc(mysqli_query($conn,"SELECT price,stock FROM products WHERE id=$pid"));
        if(!$prod||$qty<1||$qty>$prod['stock']) err('Invalid product or quantity');
        $orig=$prod['price']*$qty; $cost=max(0,$orig-$disc);
        mysqli_query($conn,"INSERT INTO purchases(product_id,customer_id,quantity,original_cost,cost,discount,date,status,notes,created_by)VALUES($pid,$cid,$qty,$orig,$cost,$disc,'$dt','Pending','$notes','$createdBy')");
        mysqli_query($conn,"UPDATE products SET stock=stock-$qty WHERE id=$pid");
        $oid=mysqli_insert_id($conn);
        mysqli_query($conn,"INSERT INTO stock_logs(product_id,change_type,quantity,date)VALUES($pid,'sale',$qty,'$dt')");
        ok(['id'=>$oid,'cost'=>$cost,'original_cost'=>$orig]);
    }
    if ($method === 'PUT' && $id) {
        $ns=mysqli_real_escape_string($conn,$input['status']??'');
        $pm=mysqli_real_escape_string($conn,$input['payment_method']??'Cash');
        $cur=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM purchases WHERE id=$id"));
        if(!$cur) err('Order not found',404);
        mysqli_query($conn,"UPDATE purchases SET status='$ns' WHERE id=$id");
        if($ns==='Delivered'&&$cur['status']!=='Delivered'){
            mysqli_query($conn,"INSERT INTO sales(purchase_id,product_id,quantity,total_price,date)VALUES({$cur['id']},{$cur['product_id']},{$cur['quantity']},{$cur['cost']},'{$cur['date']}')");
            $sid=mysqli_insert_id($conn);
            mysqli_query($conn,"INSERT INTO payments(sale_id,payment_method,amount,date)VALUES($sid,'$pm',{$cur['cost']},'{$cur['date']}')");
        }
        ok('Status updated');
    }
}

// ================================================================
// REPORTS / SALES
// ================================================================
if ($entity === 'reports') {
    requireAuth($conn);
    $sales=[];
    $r=mysqli_query($conn,"SELECT s.*,p.name pname,p.image pimg,pay.payment_method FROM sales s JOIN products p ON s.product_id=p.id LEFT JOIN payments pay ON pay.sale_id=s.id ORDER BY s.date DESC,s.id DESC LIMIT 100");
    while($row=mysqli_fetch_assoc($r)) $sales[]=$row;
    $total=mysqli_fetch_assoc(mysqli_query($conn,"SELECT IFNULL(SUM(total_price),0) t FROM sales"))['t'];
    $cnt=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM sales"))['c'];
    $month=mysqli_fetch_assoc(mysqli_query($conn,"SELECT IFNULL(SUM(total_price),0) t FROM sales WHERE DATE_FORMAT(date,'%Y-%m')=DATE_FORMAT(CURDATE(),'%Y-%m')"))['t'];
    $top=[];
    $r2=mysqli_query($conn,"SELECT p.name,p.image,SUM(s.quantity) tq,SUM(s.total_price) tr FROM sales s JOIN products p ON s.product_id=p.id GROUP BY s.product_id ORDER BY tr DESC LIMIT 5");
    while($row=mysqli_fetch_assoc($r2)) $top[]=$row;
    ok(compact('sales','total','cnt','month','top'));
}

// ================================================================
// QUOTATION CALCULATOR
// ================================================================
if ($entity === 'quotation' && $method === 'POST') {
    requireAuth($conn);
    $pid=(int)($input['product_id']??0);
    $qty=max(1,(int)($input['quantity']??1));
    $disc=(float)($input['discount']??0);
    $prod=mysqli_fetch_assoc(mysqli_query($conn,"SELECT p.*,c.category_name FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.id=$pid"));
    if(!$prod) err('Product not found',404);
    $mats=[];
    $r=mysqli_query($conn,"SELECT m.material_name,m.supplier,m.price,pm.qty FROM product_materials pm JOIN materials m ON m.material_id=pm.material_id WHERE pm.product_id=$pid");
    while($row=mysqli_fetch_assoc($r)) $mats[]=$row;
    $unitPrice=(float)$prod['price'];
    $subtotal=$unitPrice*$qty;
    $total=max(0,$subtotal-$disc);
    $matCostTotal=(float)$prod['material_cost']*$qty;
    $laborTotal=(float)$prod['labor_cost']*$qty;
    ok([
        'product'=>$prod,
        'materials'=>$mats,
        'unit_price'=>$unitPrice,
        'quantity'=>$qty,
        'subtotal'=>$subtotal,
        'discount'=>$disc,
        'total'=>$total,
        'material_cost'=>$matCostTotal,
        'labor_cost'=>$laborTotal,
        'markup'=>($matCostTotal+$laborTotal)*0.5,
    ]);
}

// ================================================================
// USERS (Admin only)
// ================================================================
if ($entity === 'users') {
    $user = requireAuth($conn);
    if($user['role']!=='admin') err('Admin only',403);
    if ($method === 'GET') {
        $rows=[];
        $r=mysqli_query($conn,"SELECT id,username,name,role,approved FROM users ORDER BY id");
        while($row=mysqli_fetch_assoc($r)) $rows[]=$row;
        ok($rows);
    }
    if ($method === 'POST') {
        $u=mysqli_real_escape_string($conn,$input['username']??'');
        $p=password_hash($input['password']??'changeme',PASSWORD_BCRYPT);
        $role=mysqli_real_escape_string($conn,$input['role']??'staff');
        $chk=mysqli_fetch_assoc(mysqli_query($conn,"SELECT id FROM users WHERE username='$u' LIMIT 1"));
        if($chk) err('Username already taken');
        mysqli_query($conn,"INSERT INTO users(username,password,role,approved)VALUES('$u','$p','$role',1)");
        ok(['id'=>mysqli_insert_id($conn)]);
    }
    if ($method === 'PUT' && $id) {
        $approved=(int)($input['approved']??1);
        mysqli_query($conn,"UPDATE users SET approved=$approved WHERE id=$id");
        ok('Updated');
    }
}

err('Not found', 404);
?>
