import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});
  @override State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  Map<String, dynamic>? _data;
  bool _loading = true;
  String? _error;

  @override void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final d = await ApiService.getReports();
      setState(() { _data = d; _loading = false; });
    } catch (e) { setState(() { _error = e.toString(); _loading = false; }); }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator(color: AppTheme.primary));
    if (_error != null) return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Icon(Icons.error_outline, size: 48, color: AppTheme.textMuted),
      const SizedBox(height: 12),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 32),
          child: Text(_error!, style: const TextStyle(color: AppTheme.rose), textAlign: TextAlign.center)),
      const SizedBox(height: 16),
      ElevatedButton.icon(onPressed: _load, icon: const Icon(Icons.refresh), label: const Text('Retry')),
    ]));

    final d = _data!;
    final sales = List.from(d['sales'] ?? []);
    final top   = List.from(d['top'] ?? []);
    final cnt   = int.tryParse(d['cnt'].toString()) ?? 0;
    final total = double.tryParse(d['total'].toString()) ?? 0;

    return RefreshIndicator(
      color: AppTheme.primary, onRefresh: _load,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

          // Stats
          GridView.count(
            shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2, childAspectRatio: 1.45, mainAxisSpacing: 10, crossAxisSpacing: 10,
            children: [
              StatCard(label: 'TOTAL REVENUE', value: formatCurrency(total), hint: 'All time', color: AppTheme.primary, icon: Icons.monetization_on),
              StatCard(label: 'THIS MONTH', value: formatCurrency(d['month']), hint: 'Current month', color: AppTheme.steel, icon: Icons.calendar_today),
              StatCard(label: 'TOTAL SALES', value: '$cnt', hint: 'Transactions', color: AppTheme.mint, icon: Icons.receipt_long),
              StatCard(label: 'AVG SALE', value: cnt > 0 ? formatCurrency(total / cnt) : '₱0.00', hint: 'Per transaction', color: const Color(0xFFE0A500), icon: Icons.trending_up),
            ],
          ),

          // Top equipment
          if (top.isNotEmpty) ...[
            const SectionHeader(title: '🏆 Top Equipment'),
            ...top.asMap().entries.map((e) {
              final colors = [AppTheme.primary, AppTheme.steel, AppTheme.mint, AppTheme.textSub, AppTheme.textMuted];
              final p = e.value;
              return Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: AppTheme.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppTheme.border)),
                child: Row(children: [
                  Container(width: 32, height: 32, decoration: BoxDecoration(color: colors[e.key].withValues(alpha: 0.15), shape: BoxShape.circle),
                      child: Center(child: Text('${e.key + 1}', style: TextStyle(fontWeight: FontWeight.w900, color: colors[e.key], fontSize: 13)))),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(p['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700, color: AppTheme.dark, fontSize: 13)),
                    Text('${p['tq']} units sold', style: const TextStyle(fontSize: 11, color: AppTheme.textSub)),
                  ])),
                  Text(formatCurrency(p['tr']), style: const TextStyle(fontWeight: FontWeight.w800, color: AppTheme.primary, fontSize: 14)),
                ]),
              );
            }),
          ],

          // Sales history
          const SectionHeader(title: '📋 Sales History'),
          if (sales.isEmpty)
            const Center(child: Padding(padding: EdgeInsets.all(32),
                child: Text('No sales recorded yet', style: TextStyle(color: AppTheme.textSub)))),
          ...sales.map((s) => Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: AppTheme.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppTheme.border)),
            child: Row(children: [
              Container(width: 44, height: 44, decoration: BoxDecoration(color: AppTheme.bg, borderRadius: BorderRadius.circular(8)), clipBehavior: Clip.antiAlias,
                child: s['pimg'] != null && s['pimg'].toString().isNotEmpty
                    ? Image.network('${ApiService.baseUrl.replaceAll('/api/api.php', '')}/${s['pimg']}', fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => const Icon(Icons.build_outlined, color: AppTheme.textMuted, size: 20))
                    : const Icon(Icons.build_outlined, color: AppTheme.textMuted, size: 20)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(s['pname'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: AppTheme.dark), maxLines: 1, overflow: TextOverflow.ellipsis),
                Row(children: [
                  Text('${s['quantity']} unit${s['quantity'] == 1 ? '' : 's'}', style: const TextStyle(fontSize: 11, color: AppTheme.textSub)),
                  if (s['payment_method'] != null) ...[
                    const SizedBox(width: 6),
                    Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                      decoration: BoxDecoration(color: AppTheme.steel.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
                      child: Text(s['payment_method'], style: const TextStyle(fontSize: 10, color: AppTheme.steel, fontWeight: FontWeight.w700))),
                  ],
                ]),
              ])),
              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text(formatCurrency(s['total_price']), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: AppTheme.primary)),
                Text(s['date'] ?? '', style: const TextStyle(fontSize: 10, color: AppTheme.textMuted)),
              ]),
            ]),
          )),
          const SizedBox(height: 80),
        ]),
      ),
    );
  }
}
