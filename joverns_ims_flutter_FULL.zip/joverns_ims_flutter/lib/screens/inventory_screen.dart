import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';

class InventoryScreen extends StatefulWidget {
  const InventoryScreen({super.key});
  @override State<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends State<InventoryScreen> with SingleTickerProviderStateMixin {
  late TabController _tabs;
  List _categories = [], _materials = [], _products = [];
  bool _loading = true;

  // Material presets — defined as class-level constant
  static const List<Map<String, String>> _materialPresets = [
    {'name': 'Rubber / Silicone',        'price': '350.00', 'img': 'uploads/RubberSilicone.jpg'},
    {'name': 'Fiberglass Insulation',    'price': '480.00', 'img': 'uploads/Fiberglass_Insulation.jpg'},
    {'name': 'Ceramic Fiber Insulation', 'price': '620.00', 'img': 'uploads/Ceramic_Fiber_Insulation.jpg'},
    {'name': 'Rockwool Insulation',      'price': '520.00', 'img': 'uploads/Rockwool_insulation.jpg'},
    {'name': 'Glass',                    'price': '750.00', 'img': 'uploads/Glass.jpg'},
    {'name': 'Stainless Steel',          'price': '1200.00','img': 'uploads/Stainless_steel.jpg'},
  ];

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 3, vsync: this);
    _load();
  }

  @override void dispose() { _tabs.dispose(); super.dispose(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final res = await Future.wait([ApiService.getCategories(), ApiService.getMaterials(), ApiService.getProducts()]);
      setState(() { _categories = res[0]; _materials = res[1]; _products = res[2]; _loading = false; });
    } catch (e) { setState(() => _loading = false); _snack(e.toString(), error: true); }
  }

  void _snack(String msg, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg), backgroundColor: error ? AppTheme.rose : AppTheme.mint,
      behavior: SnackBarBehavior.floating, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  Future<void> _deleteConfirm(String name, Future<void> Function() action) async {
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: const Text('Confirm Delete', style: TextStyle(fontWeight: FontWeight.w800)),
      content: Text('Delete "$name"?'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        ElevatedButton(onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.rose, foregroundColor: Colors.white),
            child: const Text('Delete')),
      ],
    ));
    if (ok == true) { try { await action(); _snack('🗑️ Deleted'); _load(); } catch (e) { _snack(e.toString(), error: true); } }
  }

  @override
  Widget build(BuildContext context) => Column(children: [
    Container(
      color: AppTheme.surface,
      child: TabBar(
        controller: _tabs,
        labelColor: AppTheme.primary, unselectedLabelColor: AppTheme.textMuted,
        indicatorColor: AppTheme.primary,
        labelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
        tabs: const [Tab(text: 'Categories'), Tab(text: 'Materials'), Tab(text: 'Equipment')],
      ),
    ),
    Expanded(child: _loading
        ? const Center(child: CircularProgressIndicator(color: AppTheme.primary))
        : TabBarView(controller: _tabs, children: [
            _buildCategories(),
            _buildMaterials(),
            _buildProducts(),
          ])),
  ]);

  // ── Categories ──────────────────────────────────────────────────
  Widget _buildCategories() {
    void showForm([Map? existing]) {
      final ctrl = TextEditingController(text: existing?['category_name'] ?? '');
      showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
        builder: (_) => _SimpleFormSheet(
          title: existing != null ? 'Edit Category' : '🗂️ Add Category',
          fields: [_FieldConfig(ctrl, 'Category Name *')],
          onSave: () async {
            if (ctrl.text.trim().isEmpty) throw Exception('Name required');
            existing != null
                ? await ApiService.updateCategory(int.parse(existing['id'].toString()), ctrl.text.trim(), [])
                : await ApiService.addCategory(ctrl.text.trim(), []);
            _load();
          },
        ),
      );
    }

    return RefreshIndicator(onRefresh: () async => _load(), color: AppTheme.primary,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        _AddButton('Add New Category', () => showForm()),
        const SizedBox(height: 12),
        ..._categories.map((c) => _ListTileCard(
          icon: Icons.folder_outlined, iconColor: AppTheme.primary,
          title: c['category_name'] ?? '',
          subtitle: c['mats'] ?? 'No materials assigned',
          onEdit: () => showForm(c as Map),
          onDelete: () => _deleteConfirm(c['category_name'], () => ApiService.deleteCategory(int.parse(c['id'].toString()))),
        )),
      ]),
    );
  }

  // ── Materials ───────────────────────────────────────────────────
  Widget _buildMaterials() {
    void showForm([Map? existing]) {
      final nameCtrl     = TextEditingController(text: existing?['material_name'] ?? '');
      final supplierCtrl = TextEditingController(text: existing?['supplier'] ?? '');
      final priceCtrl    = TextEditingController(text: existing?['price']?.toString() ?? '');
      String img = existing?['image'] ?? '';

      showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
        builder: (ctx) => StatefulBuilder(builder: (ctx, setS) => _SimpleFormSheet(
          title: existing != null ? 'Edit Material' : '📦 Add Material',
          extraTop: existing == null ? SizedBox(height: 100,
            child: ListView.builder(scrollDirection: Axis.horizontal, itemCount: _materialPresets.length,
              itemBuilder: (_, i) {
                final p = _materialPresets[i]; final sel = img == p['img'];
                return GestureDetector(
                  onTap: () { setS(() { nameCtrl.text = p['name']!; priceCtrl.text = p['price']!; img = p['img']!; }); },
                  child: Container(width: 90, margin: const EdgeInsets.only(right: 10),
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: sel ? AppTheme.primary : AppTheme.border, width: sel ? 2 : 1)),
                    clipBehavior: Clip.antiAlias,
                    child: Column(children: [
                      Expanded(child: Image.network('${ApiService.baseUrl.replaceAll('/api/api.php', '')}/${p['img']}',
                          fit: BoxFit.cover, width: double.infinity, errorBuilder: (_, __, ___) => Container(color: AppTheme.bg))),
                      Padding(padding: const EdgeInsets.all(4), child: Text(p['name']!, style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w600), maxLines: 2, textAlign: TextAlign.center)),
                    ]),
                  ),
                );
              },
            ),
          ) : null,
          fields: [_FieldConfig(nameCtrl, 'Material Name *'), _FieldConfig(supplierCtrl, 'Supplier *'), _FieldConfig(priceCtrl, 'Price per Unit (₱) *', type: TextInputType.number)],
          onSave: () async {
            if (nameCtrl.text.trim().isEmpty || supplierCtrl.text.trim().isEmpty) throw Exception('All fields required');
            final data = {'material_name': nameCtrl.text.trim(), 'supplier': supplierCtrl.text.trim(), 'price': double.tryParse(priceCtrl.text) ?? 0, 'image': img};
            existing != null ? await ApiService.updateMaterial(int.parse(existing['material_id'].toString()), data) : await ApiService.addMaterial(data);
            _load();
          },
        )),
      );
    }

    return RefreshIndicator(onRefresh: () async => _load(), color: AppTheme.primary,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        _AddButton('Add New Material', () => showForm()),
        const SizedBox(height: 12),
        ..._materials.map((m) => Container(
          margin: const EdgeInsets.only(bottom: 8),
          decoration: BoxDecoration(color: AppTheme.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppTheme.border)),
          child: Row(children: [
            Container(width: 72, height: 72, clipBehavior: Clip.antiAlias,
              decoration: const BoxDecoration(borderRadius: BorderRadius.horizontal(left: Radius.circular(14))),
              child: m['image'] != null && m['image'].toString().isNotEmpty
                  ? Image.network('${ApiService.baseUrl.replaceAll('/api/api.php', '')}/${m['image']}', fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(color: AppTheme.bg, child: const Icon(Icons.inventory_2_outlined, color: AppTheme.textMuted)))
                  : Container(color: AppTheme.bg, child: const Icon(Icons.inventory_2_outlined, color: AppTheme.textMuted))),
            Expanded(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(m['material_name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700, color: AppTheme.dark, fontSize: 13)),
              Text('🏭 ${m['supplier'] ?? ''}', style: const TextStyle(fontSize: 11, color: AppTheme.textSub)),
              Text(formatCurrency(m['price']), style: const TextStyle(fontWeight: FontWeight.w800, color: AppTheme.primary, fontSize: 15)),
            ]))),
            Column(mainAxisSize: MainAxisSize.min, children: [
              IconButton(icon: const Icon(Icons.edit_outlined, size: 18, color: AppTheme.textSub), onPressed: () => showForm(m as Map)),
              IconButton(icon: const Icon(Icons.delete_outline, size: 18, color: AppTheme.rose),
                  onPressed: () => _deleteConfirm(m['material_name'], () => ApiService.deleteMaterial(int.parse(m['material_id'].toString())))),
            ]),
          ]),
        )),
      ]),
    );
  }

  // ── Products ────────────────────────────────────────────────────
  Widget _buildProducts() {
    void showForm([Map? existing]) {
      showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
        builder: (_) => _ProductFormSheet(categories: _categories, materials: _materials, existing: existing, onSaved: _load));
    }

    return RefreshIndicator(onRefresh: () async => _load(), color: AppTheme.primary,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        _AddButton('Add New Equipment', () => showForm()),
        const SizedBox(height: 12),
        ..._products.map((p) => Container(
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(color: AppTheme.surface, borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppTheme.border),
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 8)]),
          clipBehavior: Clip.antiAlias,
          child: Column(children: [
            if (p['image'] != null && p['image'].toString().isNotEmpty)
              SizedBox(height: 140, width: double.infinity,
                child: Image.network('${ApiService.baseUrl.replaceAll('/api/api.php', '')}/${p['image']}', fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(height: 140, color: AppTheme.bg,
                        child: const Icon(Icons.build_outlined, size: 40, color: AppTheme.textMuted)))),
            Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text(p['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: AppTheme.dark))),
                Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(color: AppTheme.bg, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppTheme.border)),
                  child: Text(p['category_name'] ?? '—', style: const TextStyle(fontSize: 10, color: AppTheme.textSub, fontWeight: FontWeight.w600))),
              ]),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('PRICE', style: TextStyle(fontSize: 10, color: AppTheme.textMuted, fontWeight: FontWeight.w700)),
                  Text(formatCurrency(p['price']), style: const TextStyle(fontWeight: FontWeight.w800, color: AppTheme.primary, fontSize: 18)),
                ])),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('STOCK', style: TextStyle(fontSize: 10, color: AppTheme.textMuted, fontWeight: FontWeight.w700)),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: (int.tryParse(p['stock'].toString()) ?? 0) < 1 ? AppTheme.rose.withValues(alpha: 0.1) : AppTheme.mint.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(20)),
                    child: Text('${p['stock']} units', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700,
                        color: (int.tryParse(p['stock'].toString()) ?? 0) < 1 ? AppTheme.rose : AppTheme.mint))),
                ])),
              ]),
              if ((p['materials'] as List?)?.isNotEmpty == true) ...[
                const SizedBox(height: 8),
                Wrap(spacing: 4, runSpacing: 4, children: (p['materials'] as List).map((m) =>
                  Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(color: AppTheme.steel.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(20)),
                    child: Text('${m['material_name']} ×${m['qty']}', style: const TextStyle(fontSize: 10, color: AppTheme.steel, fontWeight: FontWeight.w600)))).toList()),
              ],
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: OutlinedButton.icon(icon: const Icon(Icons.edit_outlined, size: 16), label: const Text('Edit'),
                    style: OutlinedButton.styleFrom(foregroundColor: AppTheme.dark, side: const BorderSide(color: AppTheme.border)),
                    onPressed: () => showForm(p as Map))),
                const SizedBox(width: 8),
                OutlinedButton.icon(icon: const Icon(Icons.delete_outline, size: 16), label: const Text('Delete'),
                    style: OutlinedButton.styleFrom(foregroundColor: AppTheme.rose, side: const BorderSide(color: AppTheme.rose)),
                    onPressed: () => _deleteConfirm(p['name'], () => ApiService.deleteProduct(int.parse(p['id'].toString())))),
              ]),
            ])),
          ]),
        )),
      ]),
    );
  }
}

// ── Product Form Sheet ───────────────────────────────────────────
class _ProductFormSheet extends StatefulWidget {
  final List categories, materials;
  final Map? existing;
  final VoidCallback onSaved;
  const _ProductFormSheet({required this.categories, required this.materials, required this.onSaved, this.existing});
  @override State<_ProductFormSheet> createState() => _ProductFormSheetState();
}

class _ProductFormSheetState extends State<_ProductFormSheet> {
  final _nameCtrl  = TextEditingController();
  final _stockCtrl = TextEditingController();
  final _laborCtrl = TextEditingController();
  Map? _cat;
  String _img = '';
  Map<int, int> _mats = {};
  bool _saving = false;

  static const eqPresets = [
    {'name': 'Convection Oven', 'img': 'uploads/Convection_Oven.jpg'},
    {'name': 'Pizza Oven',      'img': 'uploads/Pizza_Oven.jpg'},
    {'name': 'Deck Oven',       'img': 'uploads/Deck_Oven.jpg'},
    {'name': 'Bakery Showcase', 'img': 'uploads/Bakery_Showcase.jpg'},
    {'name': 'Proofer',         'img': 'uploads/Proofer.jpg'},
    {'name': 'Rotary Oven',     'img': 'uploads/Rotary_Oven.jpg'},
  ];

  @override
  void initState() {
    super.initState();
    if (widget.existing != null) {
      final e = widget.existing!;
      _nameCtrl.text  = e['name'] ?? '';
      _stockCtrl.text = e['stock']?.toString() ?? '';
      _laborCtrl.text = e['labor_cost']?.toString() ?? '';
      _img = e['image'] ?? '';
      _cat = widget.categories.firstWhere((c) => c['id'].toString() == e['category_id']?.toString(), orElse: () => null);
      for (final m in (e['materials'] as List?) ?? []) {
        _mats[int.parse(m['material_id'].toString())] = int.parse(m['qty'].toString());
      }
    }
  }

  double get _matCost => widget.materials.fold(0.0, (s, m) {
    final mid = int.parse(m['material_id'].toString());
    return s + (_mats.containsKey(mid) ? double.parse(m['price'].toString()) * _mats[mid]! : 0);
  });
  double get _labor  => double.tryParse(_laborCtrl.text) ?? 0;
  double get _final  => (_matCost + _labor) * 1.5;

  Future<void> _save() async {
    if (_nameCtrl.text.trim().isEmpty) { _snack('Name required', error: true); return; }
    setState(() => _saving = true);
    try {
      final data = {
        'name': _nameCtrl.text.trim(),
        'category_id': _cat != null ? int.parse(_cat!['id'].toString()) : 0,
        'stock': int.tryParse(_stockCtrl.text) ?? 0,
        'labor_cost': double.tryParse(_laborCtrl.text) ?? 0,
        'image': _img,
        'mats': _mats.entries.map((e) => {'material_id': e.key, 'qty': e.value}).toList(),
      };
      widget.existing != null
          ? await ApiService.updateProduct(int.parse(widget.existing!['id'].toString()), data)
          : await ApiService.addProduct(data);
      widget.onSaved();
      if (mounted) Navigator.pop(context);
    } catch (e) { _snack(e.toString(), error: true); setState(() => _saving = false); }
  }

  void _snack(String m, {bool error = false}) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(m), backgroundColor: error ? AppTheme.rose : AppTheme.mint, behavior: SnackBarBehavior.floating));

  @override
  Widget build(BuildContext context) => Container(
    height: MediaQuery.of(context).size.height * 0.92,
    decoration: const BoxDecoration(color: AppTheme.surface, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    child: Column(children: [
      Center(child: Container(margin: const EdgeInsets.only(top: 12), width: 40, height: 4, decoration: BoxDecoration(color: AppTheme.border, borderRadius: BorderRadius.circular(2)))),
      Padding(padding: const EdgeInsets.fromLTRB(20, 16, 8, 0), child: Row(children: [
        Text(widget.existing != null ? 'Edit Equipment' : '🔧 Add Equipment', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppTheme.dark)),
        const Spacer(),
        IconButton(icon: const Icon(Icons.close, color: AppTheme.textMuted), onPressed: () => Navigator.pop(context)),
      ])),
      const Divider(height: 1, color: AppTheme.border),
      Expanded(child: SingleChildScrollView(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [

        // Image picker
        const _SectionLabel('EQUIPMENT IMAGE'),
        const SizedBox(height: 8),
        SizedBox(height: 92, child: ListView.builder(
          scrollDirection: Axis.horizontal, itemCount: eqPresets.length,
          itemBuilder: (_, i) {
            final p = eqPresets[i]; final sel = _img == p['img'];
            return GestureDetector(
              onTap: () => setState(() { _img = p['img']!; if (_nameCtrl.text.isEmpty) _nameCtrl.text = p['name']!; }),
              child: Container(width: 90, margin: const EdgeInsets.only(right: 10),
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(color: sel ? AppTheme.primary : AppTheme.border, width: sel ? 2.5 : 1)),
                clipBehavior: Clip.antiAlias,
                child: Column(children: [
                  Expanded(child: Image.network('${ApiService.baseUrl.replaceAll('/api/api.php', '')}/${p['img']}', fit: BoxFit.cover, width: double.infinity, errorBuilder: (_, __, ___) => Container(color: AppTheme.bg))),
                  Padding(padding: const EdgeInsets.all(4), child: Text(p['name']!, style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w700), maxLines: 2, textAlign: TextAlign.center)),
                ]),
              ),
            );
          },
        )),
        const SizedBox(height: 14),

        const _SectionLabel('EQUIPMENT NAME *'),
        const SizedBox(height: 6),
        TextFormField(controller: _nameCtrl, decoration: const InputDecoration(hintText: 'e.g. Deck Oven 3-Deck')),
        const SizedBox(height: 12),

        const _SectionLabel('CATEGORY'),
        const SizedBox(height: 6),
        DropdownButtonFormField<Map>(
          value: _cat,
          decoration: const InputDecoration(hintText: '— Select Category —'),
          items: widget.categories.map((c) => DropdownMenuItem<Map>(value: c as Map, child: Text(c['category_name'] ?? ''))).toList(),
          onChanged: (v) => setState(() => _cat = v),
        ),
        const SizedBox(height: 12),

        Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const _SectionLabel('STOCK *'),
            const SizedBox(height: 6),
            TextFormField(controller: _stockCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(hintText: '0')),
          ])),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const _SectionLabel('LABOR COST (₱) *'),
            const SizedBox(height: 6),
            TextFormField(controller: _laborCtrl, keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(prefixText: '₱ '), onChanged: (_) => setState(() {})),
          ])),
        ]),
        const SizedBox(height: 16),

        const _SectionLabel('MATERIALS USED'),
        const SizedBox(height: 8),
        ...widget.materials.map((m) {
          final mid = int.parse(m['material_id'].toString());
          final checked = _mats.containsKey(mid);
          final qty = _mats[mid] ?? 1;
          return Container(
            margin: const EdgeInsets.only(bottom: 6),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            decoration: BoxDecoration(
              color: checked ? AppTheme.primary.withValues(alpha: 0.05) : AppTheme.bg,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: checked ? AppTheme.primary.withValues(alpha: 0.3) : AppTheme.border),
            ),
            child: Row(children: [
              Checkbox(value: checked, activeColor: AppTheme.primary, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                onChanged: (v) => setState(() { v == true ? _mats[mid] = 1 : _mats.remove(mid); })),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(m['material_name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12, color: AppTheme.dark)),
                Text(formatCurrency(m['price']), style: const TextStyle(fontSize: 11, color: AppTheme.primary)),
              ])),
              if (checked) Row(mainAxisSize: MainAxisSize.min, children: [
                IconButton(constraints: const BoxConstraints(), padding: EdgeInsets.zero, icon: const Icon(Icons.remove_circle_outline, size: 18, color: AppTheme.primary),
                    onPressed: qty > 1 ? () => setState(() => _mats[mid] = qty - 1) : null),
                Padding(padding: const EdgeInsets.symmetric(horizontal: 6), child: Text('$qty', style: const TextStyle(fontWeight: FontWeight.w800, color: AppTheme.dark))),
                IconButton(constraints: const BoxConstraints(), padding: EdgeInsets.zero, icon: const Icon(Icons.add_circle_outline, size: 18, color: AppTheme.primary),
                    onPressed: () => setState(() => _mats[mid] = qty + 1)),
              ]),
            ]),
          );
        }),

        if (_matCost > 0 || _labor > 0) ...[
          const SizedBox(height: 14),
          Container(padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1A2540), Color(0xFF243358)]), borderRadius: BorderRadius.circular(14)),
            child: Column(children: [
              const Text('📋 PRICE QUOTATION', style: TextStyle(color: Colors.white54, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1)),
              const SizedBox(height: 10),
              _QRow('Materials', formatCurrency(_matCost)),
              _QRow('Labor', formatCurrency(_labor)),
              _QRow('Base', formatCurrency(_matCost + _labor)),
              _QRow('Markup 50%', formatCurrency((_matCost + _labor) * 0.5)),
              const Divider(color: Colors.white24, height: 14),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('FINAL PRICE', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                Text(formatCurrency(_final), style: const TextStyle(color: Color(0xFFF5C842), fontWeight: FontWeight.w900, fontSize: 18)),
              ]),
            ]),
          ),
        ],

        const SizedBox(height: 20),
        SizedBox(height: 50, child: ElevatedButton.icon(
          onPressed: _saving ? null : _save,
          icon: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.dark)) : const Icon(Icons.save_outlined),
          label: Text(widget.existing != null ? 'Update Equipment' : 'Save Equipment', style: const TextStyle(fontWeight: FontWeight.w800)),
        )),
        const SizedBox(height: 20),
      ]))),
    ]),
  );
}

// ── Shared widgets ───────────────────────────────────────────────
class _AddButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _AddButton(this.label, this.onTap);
  @override Widget build(BuildContext context) => SizedBox(width: double.infinity,
    child: ElevatedButton.icon(onPressed: onTap, icon: const Icon(Icons.add), label: Text(label),
        style: ElevatedButton.styleFrom(alignment: Alignment.centerLeft, padding: const EdgeInsets.all(14))));
}

class _ListTileCard extends StatelessWidget {
  final IconData icon; final Color iconColor;
  final String title, subtitle;
  final VoidCallback onEdit, onDelete;
  const _ListTileCard({required this.icon, required this.iconColor, required this.title, required this.subtitle, required this.onEdit, required this.onDelete});
  @override Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 8),
    decoration: BoxDecoration(color: AppTheme.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppTheme.border)),
    child: ListTile(
      leading: Container(width: 40, height: 40, decoration: BoxDecoration(color: iconColor.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
          child: Icon(icon, color: iconColor, size: 20)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, color: AppTheme.dark)),
      subtitle: Text(subtitle, style: const TextStyle(fontSize: 11, color: AppTheme.textSub), maxLines: 1, overflow: TextOverflow.ellipsis),
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        IconButton(icon: const Icon(Icons.edit_outlined, size: 18, color: AppTheme.textSub), onPressed: onEdit),
        IconButton(icon: const Icon(Icons.delete_outline, size: 18, color: AppTheme.rose), onPressed: onDelete),
      ]),
    ),
  );
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);
  @override Widget build(BuildContext context) => Text(text, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppTheme.textSub, letterSpacing: 0.5));
}

class _FieldConfig {
  final TextEditingController ctrl;
  final String label;
  final TextInputType type;
  _FieldConfig(this.ctrl, this.label, {this.type = TextInputType.text});
}

class _SimpleFormSheet extends StatefulWidget {
  final String title;
  final List<_FieldConfig> fields;
  final Future<void> Function() onSave;
  final Widget? extraTop;
  const _SimpleFormSheet({required this.title, required this.fields, required this.onSave, this.extraTop});
  @override State<_SimpleFormSheet> createState() => _SimpleFormSheetState();
}

class _SimpleFormSheetState extends State<_SimpleFormSheet> {
  bool _saving = false;
  @override Widget build(BuildContext context) => Container(
    decoration: const BoxDecoration(color: AppTheme.surface, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Center(child: Container(margin: const EdgeInsets.only(top: 12), width: 40, height: 4, decoration: BoxDecoration(color: AppTheme.border, borderRadius: BorderRadius.circular(2)))),
      Padding(padding: const EdgeInsets.fromLTRB(20, 16, 8, 0), child: Row(children: [
        Text(widget.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppTheme.dark)),
        const Spacer(),
        IconButton(icon: const Icon(Icons.close, color: AppTheme.textMuted), onPressed: () => Navigator.pop(context)),
      ])),
      const Divider(height: 1, color: AppTheme.border),
      Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        if (widget.extraTop != null) ...[widget.extraTop!, const SizedBox(height: 12)],
        ...widget.fields.map((f) => Padding(padding: const EdgeInsets.only(bottom: 10),
            child: TextFormField(controller: f.ctrl, keyboardType: f.type, decoration: InputDecoration(labelText: f.label)))),
        const SizedBox(height: 6),
        SizedBox(height: 48, child: ElevatedButton(
          onPressed: _saving ? null : () async {
            setState(() => _saving = true);
            try { await widget.onSave(); if (mounted) Navigator.pop(context); }
            catch (e) {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()), backgroundColor: AppTheme.rose, behavior: SnackBarBehavior.floating));
              setState(() => _saving = false);
            }
          },
          child: _saving ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.5, color: AppTheme.dark)) : const Text('Save', style: TextStyle(fontWeight: FontWeight.w800)),
        )),
      ])),
    ]),
  );
}

class _QRow extends StatelessWidget {
  final String l, v;
  const _QRow(this.l, this.v);
  @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 5),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(l, style: const TextStyle(color: Colors.white60, fontSize: 12)),
      Text(v, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12)),
    ]));
}
