import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import 'main_shell.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs;
  final _loginFormKey  = GlobalKey<FormState>();
  final _signupFormKey = GlobalKey<FormState>();

  final _loginUser  = TextEditingController();
  final _loginPass  = TextEditingController();
  final _signupUser  = TextEditingController();
  final _signupPass  = TextEditingController();
  final _signupPass2 = TextEditingController();
  String _signupRole = 'staff';

  bool _loading  = false;
  bool _obscure1 = true, _obscure2 = true, _obscure3 = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this);
    _tabs.addListener(() => setState(() => _error = null));
  }

  @override
  void dispose() {
    _tabs.dispose();
    _loginUser.dispose(); _loginPass.dispose();
    _signupUser.dispose(); _signupPass.dispose(); _signupPass2.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    if (!_loginFormKey.currentState!.validate()) return;
    setState(() { _loading = true; _error = null; });
    try {
      final data = await ApiService.login(_loginUser.text.trim(), _loginPass.text.trim());
      await ApiService.saveToken(data['data']['token'], data['data']['role'], data['data']['username']);
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainShell()));
    } catch (e) {
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  Future<void> _signup() async {
    if (!_signupFormKey.currentState!.validate()) return;
    setState(() { _loading = true; _error = null; });
    try {
      await ApiService.addUser(_signupUser.text.trim(), _signupPass.text.trim(), _signupRole);
      final data = await ApiService.login(_signupUser.text.trim(), _signupPass.text.trim());
      await ApiService.saveToken(data['data']['token'], data['data']['role'], data['data']['username']);
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainShell()));
    } catch (e) {
      setState(() { _error = e.toString(); _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.dark,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(children: [
            // Hero Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(24, 52, 24, 40),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                  colors: [Color(0xFF1A2540), Color(0xFF243358)],
                ),
              ),
              child: Column(children: [
                Container(
                  width: 80, height: 80,
                  decoration: BoxDecoration(
                    color: AppTheme.primary,
                    borderRadius: BorderRadius.circular(22),
                    boxShadow: [BoxShadow(
                      color: AppTheme.primary.withValues(alpha: 0.45),
                      blurRadius: 30, offset: const Offset(0, 12),
                    )],
                  ),
                  child: const Icon(Icons.precision_manufacturing_outlined, color: Colors.white, size: 40),
                ),
                const SizedBox(height: 20),
                const Text("Jovern's Fabricating",
                    style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w800, letterSpacing: -0.5)),
                const SizedBox(height: 6),
                Text('Inventory & Monitoring System',
                    style: TextStyle(color: Colors.white.withValues(alpha: 0.55), fontSize: 13)),
                const SizedBox(height: 28),
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: TabBar(
                    controller: _tabs,
                    dividerColor: Colors.transparent,
                    indicator: BoxDecoration(
                      color: AppTheme.primary,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    indicatorSize: TabBarIndicatorSize.tab,
                    labelColor: AppTheme.dark,
                    unselectedLabelColor: Colors.white.withValues(alpha: 0.6),
                    labelStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14),
                    unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                    tabs: const [Tab(text: 'Sign In'), Tab(text: 'Sign Up')],
                  ),
                ),
              ]),
            ),

            // Form Card
            Container(
              margin: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppTheme.surface,
                borderRadius: BorderRadius.circular(24),
                boxShadow: [BoxShadow(
                    color: Colors.black.withValues(alpha: 0.2),
                    blurRadius: 40, offset: const Offset(0, 16))],
              ),
              child: Column(children: [
                if (_error != null)
                  Container(
                    margin: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: AppTheme.rose.withValues(alpha: 0.08),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppTheme.rose.withValues(alpha: 0.3)),
                    ),
                    child: Row(children: [
                      const Icon(Icons.error_outline, color: AppTheme.rose, size: 18),
                      const SizedBox(width: 10),
                      Expanded(child: Text(_error!, style: const TextStyle(color: AppTheme.rose, fontSize: 13))),
                      GestureDetector(onTap: () => setState(() => _error = null),
                          child: const Icon(Icons.close, size: 16, color: AppTheme.rose)),
                    ]),
                  ),
                SizedBox(
                  height: _tabs.index == 0 ? 360 : 468,
                  child: TabBarView(
                    controller: _tabs,
                    children: [_buildLogin(), _buildSignup()],
                  ),
                ),
              ]),
            ),

            Padding(
              padding: const EdgeInsets.only(bottom: 24),
              child: Text('Default: admin / admin123',
                  style: TextStyle(color: Colors.white.withValues(alpha: 0.3), fontSize: 12)),
            ),
          ]),
        ),
      ),
    );
  }

  Widget _buildLogin() => Form(
    key: _loginFormKey,
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Text('Welcome back!', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppTheme.dark)),
        const SizedBox(height: 4),
        const Text('Sign in to your account', style: TextStyle(fontSize: 13, color: AppTheme.textSub)),
        const SizedBox(height: 28),
        TextFormField(
          controller: _loginUser,
          textInputAction: TextInputAction.next,
          decoration: const InputDecoration(labelText: 'Username',
              prefixIcon: Icon(Icons.person_outline, color: AppTheme.textMuted)),
          validator: (v) => (v?.trim().isEmpty ?? true) ? 'Username required' : null,
        ),
        const SizedBox(height: 14),
        TextFormField(
          controller: _loginPass,
          obscureText: _obscure1,
          textInputAction: TextInputAction.done,
          onFieldSubmitted: (_) => _login(),
          decoration: InputDecoration(
            labelText: 'Password',
            prefixIcon: const Icon(Icons.lock_outline, color: AppTheme.textMuted),
            suffixIcon: IconButton(
              icon: Icon(_obscure1 ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                  color: AppTheme.textMuted, size: 20),
              onPressed: () => setState(() => _obscure1 = !_obscure1),
            ),
          ),
          validator: (v) => (v?.isEmpty ?? true) ? 'Password required' : null,
        ),
        const SizedBox(height: 28),
        SizedBox(height: 52, child: ElevatedButton(
          onPressed: _loading ? null : _login,
          style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primary, foregroundColor: AppTheme.dark,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
          child: _loading
              ? const SizedBox(width: 22, height: 22,
                  child: CircularProgressIndicator(strokeWidth: 2.5, color: AppTheme.dark))
              : const Text('Sign In', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        )),
        const SizedBox(height: 16),
        Center(child: GestureDetector(
          onTap: () => _tabs.animateTo(1),
          child: RichText(text: const TextSpan(style: TextStyle(fontSize: 13), children: [
            TextSpan(text: "Don't have an account? ", style: TextStyle(color: AppTheme.textSub)),
            TextSpan(text: 'Sign Up', style: TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w700)),
          ])),
        )),
      ]),
    ),
  );

  Widget _buildSignup() => Form(
    key: _signupFormKey,
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Text('Create Account', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppTheme.dark)),
        const SizedBox(height: 4),
        const Text('Fill in your details below', style: TextStyle(fontSize: 13, color: AppTheme.textSub)),
        const SizedBox(height: 22),
        TextFormField(
          controller: _signupUser,
          textInputAction: TextInputAction.next,
          decoration: const InputDecoration(labelText: 'Username *',
              prefixIcon: Icon(Icons.person_outline, color: AppTheme.textMuted)),
          validator: (v) {
            if (v?.trim().isEmpty ?? true) return 'Username required';
            if (v!.trim().length < 3) return 'At least 3 characters';
            return null;
          },
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: _signupPass,
          obscureText: _obscure2,
          textInputAction: TextInputAction.next,
          decoration: InputDecoration(
            labelText: 'Password *',
            prefixIcon: const Icon(Icons.lock_outline, color: AppTheme.textMuted),
            suffixIcon: IconButton(
              icon: Icon(_obscure2 ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                  color: AppTheme.textMuted, size: 20),
              onPressed: () => setState(() => _obscure2 = !_obscure2),
            ),
          ),
          validator: (v) {
            if (v?.isEmpty ?? true) return 'Password required';
            if (v!.length < 6) return 'At least 6 characters';
            return null;
          },
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: _signupPass2,
          obscureText: _obscure3,
          textInputAction: TextInputAction.done,
          decoration: InputDecoration(
            labelText: 'Confirm Password *',
            prefixIcon: const Icon(Icons.lock_outline, color: AppTheme.textMuted),
            suffixIcon: IconButton(
              icon: Icon(_obscure3 ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                  color: AppTheme.textMuted, size: 20),
              onPressed: () => setState(() => _obscure3 = !_obscure3),
            ),
          ),
          validator: (v) {
            if (v?.isEmpty ?? true) return 'Confirm your password';
            if (v != _signupPass.text) return 'Passwords do not match';
            return null;
          },
        ),
        const SizedBox(height: 14),
        const Text('ROLE', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700,
            color: AppTheme.textSub, letterSpacing: 0.5)),
        const SizedBox(height: 8),
        Row(children: [
          _RoleChip(label: 'Staff', icon: Icons.badge_outlined,
              selected: _signupRole == 'staff', onTap: () => setState(() => _signupRole = 'staff')),
          const SizedBox(width: 10),
          _RoleChip(label: 'Admin', icon: Icons.admin_panel_settings_outlined,
              selected: _signupRole == 'admin', onTap: () => setState(() => _signupRole = 'admin')),
        ]),
        const SizedBox(height: 22),
        SizedBox(height: 52, child: ElevatedButton(
          onPressed: _loading ? null : _signup,
          style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primary, foregroundColor: AppTheme.dark,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
          child: _loading
              ? const SizedBox(width: 22, height: 22,
                  child: CircularProgressIndicator(strokeWidth: 2.5, color: AppTheme.dark))
              : const Text('Create Account', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        )),
        const SizedBox(height: 16),
        Center(child: GestureDetector(
          onTap: () => _tabs.animateTo(0),
          child: RichText(text: const TextSpan(style: TextStyle(fontSize: 13), children: [
            TextSpan(text: 'Already have an account? ', style: TextStyle(color: AppTheme.textSub)),
            TextSpan(text: 'Sign In', style: TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w700)),
          ])),
        )),
      ]),
    ),
  );
}

class _RoleChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;
  const _RoleChip({required this.label, required this.icon, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) => Expanded(
    child: GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFFFF8EC) : AppTheme.bg,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: selected ? AppTheme.primary : AppTheme.border, width: selected ? 2 : 1),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: selected ? AppTheme.primary : AppTheme.textMuted, size: 22),
          const SizedBox(height: 4),
          Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700,
              color: selected ? AppTheme.dark : AppTheme.textSub)),
        ]),
      ),
    ),
  );
}
