import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import 'login_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  List _users = [];
  bool _loading = true;

  @override void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    if (!ApiService.isAdmin) { setState(() => _loading = false); return; }
    setState(() => _loading = true);
    try {
      final u = await ApiService.getUsers();
      setState(() { _users = u; _loading = false; });
    } catch (e) { setState(() => _loading = false); }
  }

  void _snack(String msg, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg), backgroundColor: error ? AppTheme.rose : AppTheme.mint,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  Future<void> _logout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Sign Out', style: TextStyle(fontWeight: FontWeight.w800)),
        content: const Text('Are you sure you want to sign out?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.rose, foregroundColor: Colors.white),
            child: const Text('Sign Out'),
          ),
        ],
      ),
    );
    if (ok == true) {
      await ApiService.logout();
      if (!mounted) return;
      Navigator.pushAndRemoveUntil(
          context, MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
    }
  }

  void _showChangePassword() {
    final oldCtrl = TextEditingController();
    final newCtrl = TextEditingController();
    final conf = TextEditingController();
    final formKey = GlobalKey<FormState>();
    bool obscure1 = true, obscure2 = true, obscure3 = true;
    bool saving = false;

    showModalBottomSheet(
      context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setS) => Container(
        decoration: const BoxDecoration(color: AppTheme.surface, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Center(child: Container(margin: const EdgeInsets.only(top: 12), width: 40, height: 4,
              decoration: BoxDecoration(color: AppTheme.border, borderRadius: BorderRadius.circular(2)))),
          Padding(padding: const EdgeInsets.fromLTRB(20, 16, 8, 0), child: Row(children: [
            const Text('Change Password', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppTheme.dark)),
            const Spacer(),
            IconButton(icon: const Icon(Icons.close, color: AppTheme.textMuted), onPressed: () => Navigator.pop(ctx)),
          ])),
          const Divider(height: 1, color: AppTheme.border),
          Padding(padding: const EdgeInsets.all(20), child: Form(
            key: formKey,
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              TextFormField(
                controller: oldCtrl, obscureText: obscure1,
                decoration: InputDecoration(labelText: 'Current Password',
                  prefixIcon: const Icon(Icons.lock_outline, color: AppTheme.textMuted),
                  suffixIcon: IconButton(icon: Icon(obscure1 ? Icons.visibility_off_outlined : Icons.visibility_outlined, size: 20, color: AppTheme.textMuted),
                    onPressed: () => setS(() => obscure1 = !obscure1))),
                validator: (v) => (v?.isEmpty ?? true) ? 'Required' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: newCtrl, obscureText: obscure2,
                decoration: InputDecoration(labelText: 'New Password',
                  prefixIcon: const Icon(Icons.lock_outline, color: AppTheme.textMuted),
                  suffixIcon: IconButton(icon: Icon(obscure2 ? Icons.visibility_off_outlined : Icons.visibility_outlined, size: 20, color: AppTheme.textMuted),
                    onPressed: () => setS(() => obscure2 = !obscure2))),
                validator: (v) {
                  if (v?.isEmpty ?? true) return 'Required';
                  if (v!.length < 6) return 'At least 6 characters';
                  return null;
                },
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: conf, obscureText: obscure3,
                decoration: InputDecoration(labelText: 'Confirm New Password',
                  prefixIcon: const Icon(Icons.lock_outline, color: AppTheme.textMuted),
                  suffixIcon: IconButton(icon: Icon(obscure3 ? Icons.visibility_off_outlined : Icons.visibility_outlined, size: 20, color: AppTheme.textMuted),
                    onPressed: () => setS(() => obscure3 = !obscure3))),
                validator: (v) {
                  if (v?.isEmpty ?? true) return 'Required';
                  if (v != newCtrl.text) return 'Passwords do not match';
                  return null;
                },
              ),
              const SizedBox(height: 20),
              SizedBox(height: 50, child: ElevatedButton(
                onPressed: saving ? null : () async {
                  if (!formKey.currentState!.validate()) return;
                  setS(() => saving = true);
                  try {
                    // In a real app, you'd verify old password first. Here we call update.
                    final users = await ApiService.getUsers();
                    final me = users.firstWhere((u) => u['username'] == ApiService.username, orElse: () => null);
                    if (me != null) {
                      await ApiService.updateUser(int.parse(me['id'].toString()), me['username'], me['role'], password: newCtrl.text);
                      _snack('✅ Password updated');
                      if (ctx.mounted) Navigator.pop(ctx);
                    }
                  } catch (e) { _snack(e.toString(), error: true); setS(() => saving = false); }
                },
                child: saving ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.5, color: AppTheme.dark))
                    : const Text('Update Password', style: TextStyle(fontWeight: FontWeight.w800)),
              )),
              const SizedBox(height: 8),
            ]),
          )),
        ]),
      )),
    );
  }

  void _showAddUser() {
    final userCtrl = TextEditingController();
    final passCtrl = TextEditingController();
    String role = 'staff';
    bool saving = false;
    final formKey = GlobalKey<FormState>();

    showModalBottomSheet(
      context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setS) => Container(
        decoration: const BoxDecoration(color: AppTheme.surface, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Center(child: Container(margin: const EdgeInsets.only(top: 12), width: 40, height: 4,
              decoration: BoxDecoration(color: AppTheme.border, borderRadius: BorderRadius.circular(2)))),
          Padding(padding: const EdgeInsets.fromLTRB(20, 16, 8, 0), child: Row(children: [
            const Text('Add New User', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppTheme.dark)),
            const Spacer(),
            IconButton(icon: const Icon(Icons.close, color: AppTheme.textMuted), onPressed: () => Navigator.pop(ctx)),
          ])),
          const Divider(height: 1, color: AppTheme.border),
          Padding(padding: const EdgeInsets.all(20), child: Form(
            key: formKey,
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              TextFormField(
                controller: userCtrl, textInputAction: TextInputAction.next,
                decoration: const InputDecoration(labelText: 'Username *',
                    prefixIcon: Icon(Icons.person_outline, color: AppTheme.textMuted)),
                validator: (v) {
                  if (v?.trim().isEmpty ?? true) return 'Required';
                  if (v!.trim().length < 3) return 'At least 3 chars';
                  return null;
                },
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: passCtrl, obscureText: true,
                decoration: const InputDecoration(labelText: 'Password *',
                    prefixIcon: Icon(Icons.lock_outline, color: AppTheme.textMuted)),
                validator: (v) {
                  if (v?.isEmpty ?? true) return 'Required';
                  if (v!.length < 6) return 'At least 6 chars';
                  return null;
                },
              ),
              const SizedBox(height: 14),
              const Text('ROLE', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppTheme.textSub, letterSpacing: 0.5)),
              const SizedBox(height: 8),
              Row(children: [
                _RoleChip(label: 'Staff', icon: Icons.badge_outlined, selected: role == 'staff',
                    onTap: () => setS(() => role = 'staff')),
                const SizedBox(width: 10),
                _RoleChip(label: 'Admin', icon: Icons.admin_panel_settings_outlined, selected: role == 'admin',
                    onTap: () => setS(() => role = 'admin')),
              ]),
              const SizedBox(height: 20),
              SizedBox(height: 50, child: ElevatedButton.icon(
                onPressed: saving ? null : () async {
                  if (!formKey.currentState!.validate()) return;
                  setS(() => saving = true);
                  try {
                    await ApiService.addUser(userCtrl.text.trim(), passCtrl.text, role);
                    _snack('✅ User added'); _load();
                    if (ctx.mounted) Navigator.pop(ctx);
                  } catch (e) { _snack(e.toString(), error: true); setS(() => saving = false); }
                },
                icon: saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.dark)) : const Icon(Icons.person_add_outlined),
                label: const Text('Add User', style: TextStyle(fontWeight: FontWeight.w800)),
              )),
              const SizedBox(height: 8),
            ]),
          )),
        ]),
      )),
    );
  }

  @override
  Widget build(BuildContext context) {
    final username = ApiService.username ?? 'User';
    final role = ApiService.role ?? 'staff';
    final isAdmin = ApiService.isAdmin;
    final initial = username.isNotEmpty ? username[0].toUpperCase() : 'U';

    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: RefreshIndicator(
        color: AppTheme.primary,
        onRefresh: _load,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            // Profile Hero
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(20, 32, 20, 28),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                  colors: [Color(0xFF1A2540), Color(0xFF243358)],
                ),
              ),
              child: Column(children: [
                Container(
                  width: 72, height: 72,
                  decoration: BoxDecoration(
                    color: AppTheme.primary,
                    shape: BoxShape.circle,
                    boxShadow: [BoxShadow(
                        color: AppTheme.primary.withValues(alpha: 0.4),
                        blurRadius: 20, offset: const Offset(0, 8))],
                  ),
                  child: Center(child: Text(initial, style: const TextStyle(
                      color: Colors.white, fontSize: 28, fontWeight: FontWeight.w800))),
                ),
                const SizedBox(height: 14),
                Text(username, style: const TextStyle(
                    color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                  decoration: BoxDecoration(
                    color: isAdmin ? AppTheme.primary.withValues(alpha: 0.25) : Colors.white.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: isAdmin ? AppTheme.primary.withValues(alpha: 0.5) : Colors.white.withValues(alpha: 0.2)),
                  ),
                  child: Text(role.toUpperCase(), style: TextStyle(
                      color: isAdmin ? AppTheme.primary : Colors.white.withValues(alpha: 0.7),
                      fontSize: 11, fontWeight: FontWeight.w800, letterSpacing: 0.5)),
                ),
              ]),
            ),

            // Account Settings
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
              child: const Text('ACCOUNT', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700,
                  color: AppTheme.textMuted, letterSpacing: 0.8)),
            ),
            const SizedBox(height: 8),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                  color: AppTheme.surface, borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppTheme.border)),
              child: Column(children: [
                _SettingsTile(
                  icon: Icons.lock_outline,
                  iconColor: AppTheme.steel,
                  title: 'Change Password',
                  subtitle: 'Update your login password',
                  onTap: _showChangePassword,
                ),
              ]),
            ),

            // Admin: User Management
            if (isAdmin) ...[
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
                child: Row(children: [
                  const Text('USER MANAGEMENT', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700,
                      color: AppTheme.textMuted, letterSpacing: 0.8)),
                  const Spacer(),
                  GestureDetector(
                    onTap: _showAddUser,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                      decoration: BoxDecoration(
                        color: AppTheme.primary.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: AppTheme.primary.withValues(alpha: 0.3)),
                      ),
                      child: const Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.add, size: 14, color: AppTheme.primary),
                        SizedBox(width: 4),
                        Text('Add User', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppTheme.primary)),
                      ]),
                    ),
                  ),
                ]),
              ),
              const SizedBox(height: 8),
              _loading
                  ? const Center(child: Padding(
                      padding: EdgeInsets.all(24),
                      child: CircularProgressIndicator(color: AppTheme.primary)))
                  : Container(
                      margin: const EdgeInsets.symmetric(horizontal: 16),
                      decoration: BoxDecoration(
                          color: AppTheme.surface, borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: AppTheme.border)),
                      child: _users.isEmpty
                          ? const Padding(
                              padding: EdgeInsets.all(20),
                              child: Text('No users found', style: TextStyle(color: AppTheme.textSub)))
                          : ListView.separated(
                              shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
                              itemCount: _users.length,
                              separatorBuilder: (_, __) => const Divider(height: 1, color: AppTheme.border, indent: 60),
                              itemBuilder: (_, i) {
                                final u = _users[i];
                                final uName = u['username']?.toString() ?? '';
                                final uRole = u['role']?.toString() ?? 'staff';
                                final isMe = uName == ApiService.username;
                                return ListTile(
                                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                                  leading: CircleAvatar(
                                    backgroundColor: uRole == 'admin'
                                        ? AppTheme.primary.withValues(alpha: 0.15)
                                        : AppTheme.steel.withValues(alpha: 0.15),
                                    child: Text(uName.isNotEmpty ? uName[0].toUpperCase() : '?',
                                        style: TextStyle(
                                            fontWeight: FontWeight.w800,
                                            color: uRole == 'admin' ? AppTheme.primary : AppTheme.steel)),
                                  ),
                                  title: Row(children: [
                                    Text(uName, style: const TextStyle(fontWeight: FontWeight.w700, color: AppTheme.dark)),
                                    if (isMe) ...[
                                      const SizedBox(width: 6),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                                        decoration: BoxDecoration(color: AppTheme.mint.withValues(alpha: 0.15),
                                            borderRadius: BorderRadius.circular(10)),
                                        child: const Text('You', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: AppTheme.mint)),
                                      ),
                                    ],
                                  ]),
                                  subtitle: Text(uRole.toUpperCase(),
                                      style: const TextStyle(fontSize: 11, color: AppTheme.textMuted, fontWeight: FontWeight.w600)),
                                  trailing: isMe ? null : PopupMenuButton(
                                    icon: const Icon(Icons.more_vert, color: AppTheme.textMuted, size: 20),
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                    itemBuilder: (_) => [
                                      const PopupMenuItem(value: 'delete', child: Row(children: [
                                        Icon(Icons.delete_outline, size: 16, color: AppTheme.rose),
                                        SizedBox(width: 8),
                                        Text('Delete', style: TextStyle(color: AppTheme.rose)),
                                      ])),
                                    ],
                                    onSelected: (v) async {
                                      if (v == 'delete') {
                                        final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
                                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                          title: const Text('Delete User', style: TextStyle(fontWeight: FontWeight.w800)),
                                          content: Text('Delete user "$uName"?'),
                                          actions: [
                                            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                                            ElevatedButton(
                                              onPressed: () => Navigator.pop(context, true),
                                              style: ElevatedButton.styleFrom(backgroundColor: AppTheme.rose, foregroundColor: Colors.white),
                                              child: const Text('Delete'),
                                            ),
                                          ],
                                        ));
                                        if (ok == true) {
                                          try {
                                            await ApiService.deleteUser(int.parse(u['id'].toString()));
                                            _snack('🗑️ User deleted'); _load();
                                          } catch (e) { _snack(e.toString(), error: true); }
                                        }
                                      }
                                    },
                                  ),
                                );
                              },
                            ),
                    ),
            ],

            // App Info
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
              child: const Text('APP', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700,
                  color: AppTheme.textMuted, letterSpacing: 0.8)),
            ),
            const SizedBox(height: 8),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                  color: AppTheme.surface, borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppTheme.border)),
              child: Column(children: [
                _SettingsTile(
                  icon: Icons.info_outline,
                  iconColor: AppTheme.textSub,
                  title: "Jovern's IMS",
                  subtitle: 'Version 1.0.0',
                ),
                const Divider(height: 1, color: AppTheme.border, indent: 56),
                _SettingsTile(
                  icon: Icons.logout_outlined,
                  iconColor: AppTheme.rose,
                  title: 'Sign Out',
                  subtitle: 'Log out of your account',
                  titleColor: AppTheme.rose,
                  onTap: _logout,
                ),
              ]),
            ),
            const SizedBox(height: 32),
          ]),
        ),
      ),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String title, subtitle;
  final Color? titleColor;
  final VoidCallback? onTap;
  const _SettingsTile({
    required this.icon, required this.iconColor,
    required this.title, required this.subtitle,
    this.titleColor, this.onTap,
  });

  @override
  Widget build(BuildContext context) => ListTile(
    onTap: onTap,
    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
    leading: Container(
      width: 38, height: 38,
      decoration: BoxDecoration(
        color: iconColor.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Icon(icon, color: iconColor, size: 20),
    ),
    title: Text(title, style: TextStyle(fontWeight: FontWeight.w700, color: titleColor ?? AppTheme.dark, fontSize: 14)),
    subtitle: Text(subtitle, style: const TextStyle(fontSize: 12, color: AppTheme.textSub)),
    trailing: onTap != null ? const Icon(Icons.chevron_right, color: AppTheme.textMuted, size: 20) : null,
  );
}

class _RoleChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;
  const _RoleChip({required this.label, required this.icon, required this.selected, required this.onTap});
  @override
  Widget build(BuildContext context) => Expanded(
    child: GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFFFF8EC) : AppTheme.bg,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: selected ? AppTheme.primary : AppTheme.border, width: selected ? 2 : 1),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: selected ? AppTheme.primary : AppTheme.textMuted, size: 22),
          const SizedBox(height: 4),
          Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700,
              color: selected ? AppTheme.dark : AppTheme.textSub)),
        ]),
      ),
    ),
  );
}
