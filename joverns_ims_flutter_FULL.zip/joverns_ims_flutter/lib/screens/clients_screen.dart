import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';

class ClientsScreen extends StatefulWidget {
  const ClientsScreen({super.key});
  @override State<ClientsScreen> createState() => _ClientsScreenState();
}

class _ClientsScreenState extends State<ClientsScreen> {
  List _clients = [];
  bool _loading = true;
  String _search = '';

  @override void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final c = await ApiService.getCustomers();
      setState(() { _clients = c; _loading = false; });
    } catch (e) { setState(() => _loading = false); _snack(e.toString(), error: true); }
  }

  void _snack(String msg, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg), backgroundColor: error ? AppTheme.rose : AppTheme.mint,
      behavior: SnackBarBehavior.floating, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  void _showForm([Map? existing]) {
    final nameCtrl    = TextEditingController(text: existing?['customer_name'] ?? '');
    final contactCtrl = TextEditingController(text: existing?['contact'] ?? '');
    final emailCtrl   = TextEditingController(text: existing?['email'] ?? '');
    final addrCtrl    = TextEditingController(text: existing?['address'] ?? '');
    String clientType = existing?['client_type'] ?? 'Walk-in';
    String payTerms   = existing?['payment_terms'] ?? 'COD';

    showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setS) => Container(
        decoration: const BoxDecoration(color: AppTheme.surface, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Center(child: Container(margin: const EdgeInsets.only(top: 12), width: 40, height: 4, decoration: BoxDecoration(color: AppTheme.border, borderRadius: BorderRadius.circular(2)))),
          Padding(padding: const EdgeInsets.fromLTRB(20, 16, 8, 0), child: Row(children: [
            Text(existing != null ? 'Edit Client' : '👥 Add New Client', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppTheme.dark)),
            const Spacer(),
            IconButton(icon: const Icon(Icons.close, color: AppTheme.textMuted), onPressed: () => Navigator.pop(ctx)),
          ])),
          const Divider(height: 1, color: AppTheme.border),
          Flexible(child: SingleChildScrollView(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            TextFormField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Client Name *')),
            const SizedBox(height: 10),
            TextFormField(controller: contactCtrl, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Contact Number', hintText: '09xx-xxx-xxxx')),
            const SizedBox(height: 10),
            TextFormField(controller: emailCtrl, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email')),
            const SizedBox(height: 10),
            TextFormField(controller: addrCtrl, decoration: const InputDecoration(labelText: 'Address', hintText: 'City, Province')),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: DropdownButtonFormField<String>(
                value: clientType, decoration: const InputDecoration(labelText: 'Client Type'),
                items: ['Walk-in', 'Regular', 'Corporate', 'Government'].map((t) => DropdownMenuItem(value: t, child: Text(t))).toList(),
                onChanged: (v) => setS(() => clientType = v!),
              )),
              const SizedBox(width: 10),
              Expanded(child: DropdownButtonFormField<String>(
                value: payTerms, decoration: const InputDecoration(labelText: 'Payment Terms'),
                items: ['COD', '30 days', '60 days', 'Credit', 'DP+Balance'].map((t) => DropdownMenuItem(value: t, child: Text(t))).toList(),
                onChanged: (v) => setS(() => payTerms = v!),
              )),
            ]),
            const SizedBox(height: 20),
            SizedBox(height: 48, child: ElevatedButton.icon(
              icon: const Icon(Icons.save_outlined),
              label: Text(existing != null ? 'Update Client' : 'Save Client', style: const TextStyle(fontWeight: FontWeight.w800)),
              onPressed: () async {
                if (nameCtrl.text.trim().isEmpty) { _snack('Client name required', error: true); return; }
                final data = {
                  'customer_name': nameCtrl.text.trim(),
                  'contact': contactCtrl.text,
                  'email': emailCtrl.text,
                  'address': addrCtrl.text,
                  'client_type': clientType,
                  'payment_terms': payTerms,
                };
                try {
                  existing != null
                      ? await ApiService.updateCustomer(int.parse(existing['id'].toString()), data)
                      : await ApiService.addCustomer(data);
                  _snack(existing != null ? '✅ Updated' : '✅ Client added');
                  _load();
                  if (ctx.mounted) Navigator.pop(ctx);
                } catch (e) { _snack(e.toString(), error: true); }
              },
            )),
          ]))),
        ]),
      )),
    );
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _clients.where((c) =>
        c['customer_name'].toString().toLowerCase().contains(_search.toLowerCase())).toList();

    return Scaffold(
      backgroundColor: AppTheme.bg,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showForm(),
        backgroundColor: AppTheme.primary, foregroundColor: AppTheme.dark,
        icon: const Icon(Icons.person_add_outlined),
        label: const Text('Add Client', style: TextStyle(fontWeight: FontWeight.w700)),
      ),
      body: Column(children: [
        Padding(padding: const EdgeInsets.all(14),
          child: TextField(
            onChanged: (v) => setState(() => _search = v),
            decoration: InputDecoration(
              hintText: 'Search clients…',
              prefixIcon: const Icon(Icons.search, color: AppTheme.textMuted),
              filled: true, fillColor: AppTheme.surface,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: AppTheme.border)),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: AppTheme.border)),
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
            ),
          ),
        ),
        Expanded(child: _loading
            ? const Center(child: CircularProgressIndicator(color: AppTheme.primary))
            : RefreshIndicator(
                color: AppTheme.primary, onRefresh: _load,
                child: filtered.isEmpty
                    ? ListView(children: const [SizedBox(height: 200,
                        child: Center(child: Text('No clients found', style: TextStyle(color: AppTheme.textSub))))])
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(14, 0, 14, 100),
                        itemCount: filtered.length,
                        itemBuilder: (_, i) {
                          final c = filtered[i];
                          return Container(
                            margin: const EdgeInsets.only(bottom: 8),
                            decoration: BoxDecoration(color: AppTheme.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppTheme.border)),
                            child: ListTile(
                              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                              leading: CircleAvatar(
                                backgroundColor: AppTheme.primary.withValues(alpha: 0.15),
                                child: Text((c['customer_name'] as String)[0].toUpperCase(),
                                    style: const TextStyle(fontWeight: FontWeight.w800, color: AppTheme.primary)),
                              ),
                              title: Text(c['customer_name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700, color: AppTheme.dark)),
                              subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                if ((c['contact'] ?? '').toString().isNotEmpty)
                                  Text(c['contact'], style: const TextStyle(fontSize: 12, color: AppTheme.textSub)),
                                const SizedBox(height: 4),
                                Row(children: [
                                  _Badge(c['client_type'] ?? 'Walk-in', AppTheme.border, AppTheme.textSub),
                                  const SizedBox(width: 4),
                                  _Badge(c['payment_terms'] ?? 'COD', AppTheme.primary.withValues(alpha: 0.15), AppTheme.primary),
                                ]),
                              ]),
                              trailing: PopupMenuButton(
                                icon: const Icon(Icons.more_vert, color: AppTheme.textMuted, size: 20),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                itemBuilder: (_) => [
                                  const PopupMenuItem(value: 'edit', child: Row(children: [Icon(Icons.edit_outlined, size: 16), SizedBox(width: 8), Text('Edit')])),
                                  const PopupMenuItem(value: 'delete', child: Row(children: [Icon(Icons.delete_outline, size: 16, color: AppTheme.rose), SizedBox(width: 8), Text('Delete', style: TextStyle(color: AppTheme.rose))])),
                                ],
                                onSelected: (v) async {
                                  if (v == 'edit') _showForm(c as Map);
                                  if (v == 'delete') {
                                    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                      title: const Text('Delete Client'),
                                      content: Text('Delete "${c['customer_name']}"?'),
                                      actions: [
                                        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                                        ElevatedButton(onPressed: () => Navigator.pop(context, true),
                                            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.rose, foregroundColor: Colors.white),
                                            child: const Text('Delete')),
                                      ],
                                    ));
                                    if (ok == true) {
                                      await ApiService.deleteCustomer(int.parse(c['id'].toString()));
                                      _snack('🗑️ Deleted'); _load();
                                    }
                                  }
                                },
                              ),
                            ),
                          );
                        },
                      ),
              )),
      ]),
    );
  }
}

class _Badge extends StatelessWidget {
  final String text;
  final Color bg, fg;
  const _Badge(this.text, this.bg, this.fg);
  @override Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20), border: Border.all(color: bg)),
    child: Text(text, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: fg)),
  );
}
