import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  Map<String, dynamic>? _data;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final d = await ApiService.getDashboard();
      setState(() {
        _data = d;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Center(child: CircularProgressIndicator(color: AppTheme.primary));
    }

    if (_error != null) {
      return Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.wifi_off_outlined, size: 48, color: AppTheme.textMuted),
          const SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 32),
            child: Text(_error!,
                style: const TextStyle(color: AppTheme.rose),
                textAlign: TextAlign.center),
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: _load,
            icon: const Icon(Icons.refresh),
            label: const Text('Retry'),
          ),
        ]),
      );
    }

    final d = _data!;
    final outOfStock = List<dynamic>.from(d['outOfStock'] ?? []);
    final recent = List<dynamic>.from(d['recentOrders'] ?? []);
    final trend = List<dynamic>.from(d['trend'] ?? []);

    final List<Widget> children = [];

    // Greeting banner
    children.add(Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
            colors: [Color(0xFF1A2540), Color(0xFF243358)]),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(children: [
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Good day! 👋',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text(
              '${ApiService.username} · ${ApiService.role?.toUpperCase()}',
              style: TextStyle(
                  color: Colors.white.withValues(alpha: 0.65), fontSize: 12),
            ),
          ]),
        ),
        Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
              color: AppTheme.primary,
              borderRadius: BorderRadius.circular(20)),
          child: Text(
            '${d['orders']} Active Orders',
            style: const TextStyle(
                color: Colors.white,
                fontSize: 11,
                fontWeight: FontWeight.w700),
          ),
        ),
      ]),
    ));

    children.add(const SizedBox(height: 14));

    // Out of stock alert
    if (outOfStock.isNotEmpty) {
      final names = outOfStock
          .map((e) => (e as Map)['name']?.toString() ?? '')
          .join(', ');
      children.add(Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AppTheme.rose.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppTheme.rose.withValues(alpha: 0.3)),
        ),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Icon(Icons.warning_amber_rounded,
              color: AppTheme.rose, size: 20),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Out of Stock',
                      style: TextStyle(
                          fontWeight: FontWeight.w800,
                          color: AppTheme.rose,
                          fontSize: 13)),
                  const SizedBox(height: 2),
                  Text(names,
                      style: const TextStyle(
                          fontSize: 12, color: AppTheme.rose)),
                ]),
          ),
        ]),
      ));
      children.add(const SizedBox(height: 14));
    }

    // Stats grid
    children.add(GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      childAspectRatio: 1.45,
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      children: [
        StatCard(
            label: 'DAILY SALES',
            value: formatCurrency(d['daily']),
            hint: 'Today',
            color: AppTheme.primary,
            icon: Icons.today),
        StatCard(
            label: 'MONTHLY SALES',
            value: formatCurrency(d['month']),
            hint: 'This month',
            color: AppTheme.steel,
            icon: Icons.calendar_month),
        StatCard(
            label: 'TOTAL REVENUE',
            value: formatCurrency(d['total']),
            hint: 'All time',
            color: AppTheme.mint,
            icon: Icons.monetization_on),
        StatCard(
            label: 'CLIENTS',
            value: '${d['clients']}',
            hint: '${d['orders']} active orders',
            color: const Color(0xFFE0A500),
            icon: Icons.people),
      ],
    ));

    // Trend chart
    if (trend.isNotEmpty) {
      final spots = trend.asMap().entries.map((e) {
        final val =
            double.tryParse((e.value as Map)['t'].toString()) ?? 0;
        return FlSpot(e.key.toDouble(), val);
      }).toList();

      children.add(const SectionHeader(title: '📈 Sales Trend — 30 Days'));
      children.add(Container(
        height: 180,
        padding: const EdgeInsets.fromLTRB(12, 16, 12, 8),
        decoration: BoxDecoration(
            color: AppTheme.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.border)),
        child: LineChart(LineChartData(
          gridData: FlGridData(
            show: true,
            drawVerticalLine: false,
            getDrawingHorizontalLine: (_) =>
                const FlLine(color: Color(0xFFE8EDF5), strokeWidth: 1),
          ),
          titlesData: FlTitlesData(
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 44,
                getTitlesWidget: (v, _) => Text(
                  '₱${(v / 1000).toStringAsFixed(0)}k',
                  style: const TextStyle(
                      fontSize: 9, color: AppTheme.textMuted),
                ),
              ),
            ),
            bottomTitles: const AxisTitles(
                sideTitles: SideTitles(showTitles: false)),
            topTitles: const AxisTitles(
                sideTitles: SideTitles(showTitles: false)),
            rightTitles: const AxisTitles(
                sideTitles: SideTitles(showTitles: false)),
          ),
          borderData: FlBorderData(show: false),
          lineBarsData: [
            LineChartBarData(
              spots: spots,
              isCurved: true,
              color: AppTheme.primary,
              barWidth: 2.5,
              dotData: const FlDotData(show: false),
              belowBarData: BarAreaData(
                  show: true,
                  color: AppTheme.primary.withValues(alpha: 0.08)),
            ),
          ],
        )),
      ));
    }

    // Recent orders
    if (recent.isNotEmpty) {
      children.add(const SectionHeader(title: '🛒 Recent Orders'));
      for (final o in recent) {
        children.add(_OrderTile(order: o as Map));
      }
    }

    children.add(const SizedBox(height: 30));

    return RefreshIndicator(
      color: AppTheme.primary,
      onRefresh: _load,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: children,
        ),
      ),
    );
  }
}

class _OrderTile extends StatelessWidget {
  final Map order;
  const _OrderTile({required this.order});

  @override
  Widget build(BuildContext context) {
    final imgUrl = order['pimg']?.toString() ?? '';
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
          color: AppTheme.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppTheme.border)),
      child: Row(children: [
        Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
              color: AppTheme.bg,
              borderRadius: BorderRadius.circular(8)),
          clipBehavior: Clip.antiAlias,
          child: imgUrl.isNotEmpty
              ? Image.network(
                  '${ApiService.baseUrl.replaceAll('/api/api.php', '')}/$imgUrl',
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => const Icon(
                      Icons.build_outlined,
                      color: AppTheme.textMuted,
                      size: 20),
                )
              : const Icon(Icons.build_outlined,
                  color: AppTheme.textMuted, size: 20),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  order['pname']?.toString() ?? '',
                  style: const TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                      color: AppTheme.dark),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  order['customer_name']?.toString() ?? 'Walk-in',
                  style: const TextStyle(
                      fontSize: 11, color: AppTheme.textSub),
                ),
              ]),
        ),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text(
            formatCurrency(order['cost']),
            style: const TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 13,
                color: AppTheme.primary),
          ),
          const SizedBox(height: 4),
          statusBadge(order['status']?.toString() ?? 'Pending'),
        ]),
      ]),
    );
  }
}
