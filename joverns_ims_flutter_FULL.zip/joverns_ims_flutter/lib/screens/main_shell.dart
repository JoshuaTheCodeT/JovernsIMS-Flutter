import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import 'dashboard_screen.dart';
import 'orders_screen.dart';
import 'inventory_screen.dart';
import 'clients_screen.dart';
import 'reports_screen.dart';
import 'profile_screen.dart';
import 'login_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _idx = 0;

  static const _labels = ['Dashboard', 'Orders', 'Inventory', 'Clients', 'Reports', 'Profile'];
  static const _icons = [
    Icons.dashboard_outlined, Icons.shopping_cart_outlined, Icons.inventory_2_outlined,
    Icons.people_outline, Icons.bar_chart_outlined, Icons.person_outline,
  ];
  static const _activeIcons = [
    Icons.dashboard, Icons.shopping_cart, Icons.inventory_2,
    Icons.people, Icons.bar_chart, Icons.person,
  ];

  final List<Widget> _screens = const [
    DashboardScreen(), OrdersScreen(), InventoryScreen(),
    ClientsScreen(), ReportsScreen(), ProfileScreen(),
  ];

  Future<void> _logout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Sign Out', style: TextStyle(fontWeight: FontWeight.w800)),
        content: const Text('Are you sure you want to sign out?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.rose, foregroundColor: Colors.white),
            child: const Text('Sign Out'),
          ),
        ],
      ),
    );
    if (ok == true) {
      await ApiService.logout();
      if (!mounted) return;
      Navigator.pushAndRemoveUntil(
          context, MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
    }
  }

  String get _appBarTitle => _labels[_idx];

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      titleSpacing: 16,
      title: Row(children: [
        Container(
          width: 32, height: 32,
          decoration: BoxDecoration(color: AppTheme.primary, borderRadius: BorderRadius.circular(8)),
          child: const Icon(Icons.precision_manufacturing_outlined, color: Colors.white, size: 18),
        ),
        const SizedBox(width: 10),
        Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Text(_appBarTitle, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppTheme.dark)),
          Text(ApiService.role?.toUpperCase() ?? '', style: const TextStyle(fontSize: 10, color: AppTheme.textMuted, fontWeight: FontWeight.w600)),
        ]),
      ]),
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 4),
          child: GestureDetector(
            onTap: () => setState(() => _idx = 5),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: AppTheme.primary.withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AppTheme.primary.withValues(alpha: 0.4)),
              ),
              child: Text(ApiService.username?.toUpperCase() ?? '',
                  style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: AppTheme.primary)),
            ),
          ),
        ),
        IconButton(
          icon: const Icon(Icons.logout_outlined, color: AppTheme.textSub, size: 20),
          onPressed: _logout,
        ),
      ],
      bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppTheme.border, height: 1)),
    ),
    body: IndexedStack(index: _idx, children: _screens),
    bottomNavigationBar: Container(
      decoration: const BoxDecoration(
        color: AppTheme.surface,
        border: Border(top: BorderSide(color: AppTheme.border)),
        boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10)],
      ),
      child: BottomNavigationBar(
        currentIndex: _idx,
        onTap: (i) => setState(() => _idx = i),
        elevation: 0,
        backgroundColor: Colors.transparent,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: AppTheme.primary,
        unselectedItemColor: AppTheme.textMuted,
        selectedFontSize: 10,
        unselectedFontSize: 10,
        items: List.generate(_labels.length, (i) => BottomNavigationBarItem(
          icon: Icon(_icons[i], size: 22),
          activeIcon: Icon(_activeIcons[i], size: 22),
          label: _labels[i],
        )),
      ),
    ),
  );
}
