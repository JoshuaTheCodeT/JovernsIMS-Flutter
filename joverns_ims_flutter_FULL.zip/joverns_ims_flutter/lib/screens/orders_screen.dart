import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});
  @override State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  List _orders = [], _products = [], _customers = [];
  bool _loading = true;

  @override void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final res = await Future.wait([ApiService.getPurchases(), ApiService.getProducts(), ApiService.getCustomers()]);
      setState(() { _orders = res[0]; _products = res[1]; _customers = res[2]; _loading = false; });
    } catch (e) { setState(() => _loading = false); _snack(e.toString(), error: true); }
  }

  void _snack(String msg, {bool error = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg), backgroundColor: error ? AppTheme.rose : AppTheme.mint,
      behavior: SnackBarBehavior.floating, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  Future<void> _updateStatus(Map order) async {
    String selected = order['status'];
    String paymentMethod = 'Cash';
    final result = await showModalBottomSheet<bool>(
      context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (_) => _StatusSheet(
        order: order,
        selected: selected,
        onStatusChanged: (s) => selected = s,
        onPaymentChanged: (p) => paymentMethod = p,
      ),
    );
    if (result == true) {
      try {
        await ApiService.updatePurchaseStatus(int.parse(order['id'].toString()), selected, paymentMethod);
        _snack('✅ Status updated'); _load();
      } catch (e) { _snack(e.toString(), error: true); }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: AppTheme.bg,
    floatingActionButton: FloatingActionButton.extended(
      onPressed: () async {
        await showModalBottomSheet(
          context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
          builder: (_) => _NewOrderSheet(products: _products, customers: _customers, onSaved: _load),
        );
      },
      backgroundColor: AppTheme.primary, foregroundColor: AppTheme.dark,
      icon: const Icon(Icons.add),
      label: const Text('New Order', style: TextStyle(fontWeight: FontWeight.w700)),
    ),
    body: _loading
        ? const Center(child: CircularProgressIndicator(color: AppTheme.primary))
        : RefreshIndicator(
            color: AppTheme.primary, onRefresh: _load,
            child: _orders.isEmpty
                ? ListView(children: [
                    SizedBox(height: MediaQuery.of(context).size.height * 0.35,
                      child: const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.shopping_cart_outlined, size: 56, color: AppTheme.textMuted),
                        SizedBox(height: 12),
                        Text('No active orders', style: TextStyle(color: AppTheme.textSub, fontSize: 15)),
                      ]))),
                  ])
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
                    itemCount: _orders.length,
                    itemBuilder: (_, i) => _OrderCard(order: _orders[i], onTap: () => _updateStatus(_orders[i])),
                  ),
          ),
  );
}

class _OrderCard extends StatelessWidget {
  final Map order;
  final VoidCallback onTap;
  const _OrderCard({required this.order, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(color: AppTheme.surface, borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppTheme.border),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 8, offset: const Offset(0, 2))]),
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            Container(width: 52, height: 52, decoration: BoxDecoration(color: AppTheme.bg, borderRadius: BorderRadius.circular(10)),
              clipBehavior: Clip.antiAlias,
              child: order['pimg'] != null && order['pimg'].toString().isNotEmpty
                  ? Image.network('${ApiService.baseUrl.replaceAll('/api/api.php', '')}/${order['pimg']}', fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const Icon(Icons.build_outlined, color: AppTheme.textMuted, size: 24))
                  : const Icon(Icons.build_outlined, color: AppTheme.textMuted, size: 24),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Text('#${order['id']}', style: const TextStyle(fontSize: 11, color: AppTheme.textMuted)),
                const SizedBox(width: 6),
                statusBadge(order['status'] ?? 'Pending'),
              ]),
              const SizedBox(height: 4),
              Text(order['pname'] ?? '', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14, color: AppTheme.dark),
                  maxLines: 1, overflow: TextOverflow.ellipsis),
              Text(order['customer_name'] ?? 'Walk-in', style: const TextStyle(fontSize: 12, color: AppTheme.textSub)),
            ])),
          ]),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: const BoxDecoration(color: AppTheme.bg, borderRadius: BorderRadius.vertical(bottom: Radius.circular(16))),
          child: Row(children: [
            Expanded(child: _InfoChip('Qty', '${order['quantity']} unit${order['quantity'] == 1 ? '' : 's'}')),
            Expanded(child: _InfoChip('Total', formatCurrency(order['cost']), highlight: true)),
            Expanded(child: _InfoChip('Date', (order['date'] ?? '').toString().length > 10 ? order['date'].toString().substring(0, 10) : order['date'] ?? '')),
          ]),
        ),
      ]),
    ),
  );
}

class _InfoChip extends StatelessWidget {
  final String label, value;
  final bool highlight;
  const _InfoChip(this.label, this.value, {this.highlight = false});
  @override Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(label, style: const TextStyle(fontSize: 10, color: AppTheme.textMuted, fontWeight: FontWeight.w600)),
    const SizedBox(height: 2),
    Text(value, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700,
        color: highlight ? AppTheme.primary : AppTheme.dark), maxLines: 1, overflow: TextOverflow.ellipsis),
  ]);
}

// ── New Order Sheet ──────────────────────────────────────────────
class _NewOrderSheet extends StatefulWidget {
  final List products, customers;
  final VoidCallback onSaved;
  const _NewOrderSheet({required this.products, required this.customers, required this.onSaved});
  @override State<_NewOrderSheet> createState() => _NewOrderSheetState();
}

class _NewOrderSheetState extends State<_NewOrderSheet> {
  Map? _product, _customer;
  int _qty = 1;
  double _discount = 0;
  final _notesCtrl = TextEditingController();
  bool _saving = false;
  Map<String, dynamic>? _quotation;

  Future<void> _loadQuotation() async {
    if (_product == null) return;
    try {
      final q = await ApiService.getQuotation(int.parse(_product!['id'].toString()), _qty, _discount);
      setState(() => _quotation = q);
    } catch (_) {}
  }

  Future<void> _save() async {
    if (_product == null) { _snack('Please select a product', error: true); return; }
    final maxStock = int.tryParse(_product!['stock']?.toString() ?? '0') ?? 0;
    if (_qty < 1 || _qty > maxStock) { _snack('Invalid quantity', error: true); return; }
    setState(() => _saving = true);
    try {
      await ApiService.addPurchase({
        'product_id': _product!['id'],
        if (_customer != null) 'customer_id': _customer!['id'],
        'quantity': _qty,
        'discount': _discount,
        'notes': _notesCtrl.text,
        'date': DateTime.now().toIso8601String().substring(0, 10),
        'created_by': ApiService.role ?? 'app',
      });
      widget.onSaved();
      if (mounted) Navigator.pop(context);
    } catch (e) { _snack(e.toString(), error: true); setState(() => _saving = false); }
  }

  void _snack(String msg, {bool error = false}) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg), backgroundColor: error ? AppTheme.rose : AppTheme.mint,
      behavior: SnackBarBehavior.floating, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))));

  @override
  Widget build(BuildContext context) {
    final maxStock = int.tryParse(_product?['stock']?.toString() ?? '0') ?? 0;
    final unitPrice = double.tryParse(_product?['price']?.toString() ?? '0') ?? 0;
    final subtotal = unitPrice * _qty;
    final total = (subtotal - _discount).clamp(0.0, double.infinity);

    return Container(
      decoration: const BoxDecoration(color: AppTheme.surface, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Center(child: Container(margin: const EdgeInsets.only(top: 12), width: 40, height: 4, decoration: BoxDecoration(color: AppTheme.border, borderRadius: BorderRadius.circular(2)))),
        Padding(padding: const EdgeInsets.fromLTRB(20, 16, 8, 0), child: Row(children: [
          const Text('🛒 New Order', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppTheme.dark)),
          const Spacer(),
          IconButton(icon: const Icon(Icons.close, color: AppTheme.textMuted), onPressed: () => Navigator.pop(context)),
        ])),
        Flexible(child: SingleChildScrollView(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [

          // Product picker
          const _Label('EQUIPMENT *'),
          const SizedBox(height: 6),
          GestureDetector(
            onTap: () async {
              final p = await showModalBottomSheet<Map>(
                context: context, backgroundColor: Colors.transparent, isScrollControlled: true,
                builder: (_) => _ProductPickerSheet(products: widget.products),
              );
              if (p != null) { setState(() { _product = p; _qty = 1; _quotation = null; }); _loadQuotation(); }
            },
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _product != null ? const Color(0xFFFFF8EC) : AppTheme.bg,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _product != null ? AppTheme.primary : AppTheme.border),
              ),
              child: _product != null
                  ? Row(children: [
                      Container(width: 44, height: 44, decoration: BoxDecoration(color: AppTheme.bg, borderRadius: BorderRadius.circular(8)), clipBehavior: Clip.antiAlias,
                        child: _product!['image'] != null && _product!['image'].toString().isNotEmpty
                            ? Image.network('${ApiService.baseUrl.replaceAll('/api/api.php', '')}/${_product!['image']}', fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.build_outlined, size: 20))
                            : const Icon(Icons.build_outlined, size: 20, color: AppTheme.textMuted)),
                      const SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(_product!['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700, color: AppTheme.dark)),
                        Text(formatCurrency(_product!['price']) + ' / unit', style: const TextStyle(fontSize: 12, color: AppTheme.primary)),
                      ])),
                      const Icon(Icons.swap_horiz, color: AppTheme.primary, size: 18),
                    ])
                  : const Row(children: [
                      Icon(Icons.image_outlined, color: AppTheme.textMuted, size: 20),
                      SizedBox(width: 10),
                      Text('Pick Equipment from Catalogue', style: TextStyle(color: AppTheme.textSub)),
                      Spacer(),
                      Icon(Icons.arrow_forward_ios, color: AppTheme.textMuted, size: 14),
                    ]),
            ),
          ),
          const SizedBox(height: 14),

          // Customer
          const _Label('CLIENT'),
          const SizedBox(height: 6),
          DropdownButtonFormField<Map>(
            value: _customer,
            decoration: const InputDecoration(hintText: 'Walk-in / No Client'),
            items: [
              const DropdownMenuItem(value: null, child: Text('Walk-in / No Client')),
              ...widget.customers.map((c) => DropdownMenuItem<Map>(value: c as Map, child: Text(c['customer_name'] ?? ''))),
            ],
            onChanged: (v) => setState(() => _customer = v),
          ),
          const SizedBox(height: 14),

          Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const _Label('QUANTITY *'),
              const SizedBox(height: 6),
              Row(children: [
                IconButton(icon: const Icon(Icons.remove_circle_outline, color: AppTheme.primary, size: 28),
                    onPressed: _qty > 1 ? () { setState(() => _qty--); _loadQuotation(); } : null),
                Text('$_qty', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: AppTheme.dark)),
                IconButton(icon: const Icon(Icons.add_circle_outline, color: AppTheme.primary, size: 28),
                    onPressed: _qty < maxStock ? () { setState(() => _qty++); _loadQuotation(); } : null),
              ]),
              Text('Max: $maxStock in stock', style: const TextStyle(fontSize: 10, color: AppTheme.textMuted)),
            ])),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const _Label('DISCOUNT (₱)'),
              const SizedBox(height: 6),
              TextFormField(
                initialValue: '0',
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(prefixText: '₱ '),
                onChanged: (v) { _discount = double.tryParse(v) ?? 0; _loadQuotation(); },
              ),
            ])),
          ]),
          const SizedBox(height: 14),

          const _Label('NOTES'),
          const SizedBox(height: 6),
          TextFormField(controller: _notesCtrl, maxLines: 2, decoration: const InputDecoration(hintText: 'Special instructions...')),
          const SizedBox(height: 16),

          // Quotation
          if (_product != null) Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF1A2540), Color(0xFF243358)]),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Column(children: [
              const Text('📋 ORDER QUOTATION', style: TextStyle(color: Colors.white70, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1)),
              const SizedBox(height: 12),
              _QRow('Unit Price', formatCurrency(unitPrice)),
              _QRow('Quantity', '$_qty unit${_qty == 1 ? '' : 's'}'),
              _QRow('Subtotal', formatCurrency(subtotal)),
              if (_discount > 0) _QRow('Discount', '– ${formatCurrency(_discount)}', valueColor: AppTheme.rose),
              const Divider(color: Colors.white24, height: 20),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('TOTAL AMOUNT DUE', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13)),
                Text(formatCurrency(total), style: const TextStyle(color: Color(0xFFF5C842), fontWeight: FontWeight.w900, fontSize: 20)),
              ]),
              if (_quotation != null && (_quotation!['materials'] as List?)?.isNotEmpty == true) ...[
                const SizedBox(height: 12),
                const Divider(color: Colors.white24),
                const SizedBox(height: 6),
                const Align(alignment: Alignment.centerLeft, child: Text('MATERIALS', style: TextStyle(color: Colors.white54, fontSize: 10, fontWeight: FontWeight.w700))),
                const SizedBox(height: 6),
                ...(_quotation!['materials'] as List).map((m) => Padding(
                  padding: const EdgeInsets.only(bottom: 3),
                  child: Row(children: [
                    Expanded(child: Text('${m['material_name']} × ${m['qty']}', style: const TextStyle(color: Colors.white70, fontSize: 11))),
                    Text(formatCurrency(double.parse(m['price'].toString()) * int.parse(m['qty'].toString()) * _qty),
                        style: const TextStyle(color: Colors.white70, fontSize: 11)),
                  ]),
                )),
              ],
            ]),
          ),
          const SizedBox(height: 20),

          SizedBox(height: 50, child: ElevatedButton.icon(
            onPressed: _saving ? null : _save,
            icon: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.dark)) : const Icon(Icons.save_outlined),
            label: const Text('Save Order', style: TextStyle(fontWeight: FontWeight.w800)),
          )),
        ]))),
      ]),
    );
  }
}

class _Label extends StatelessWidget {
  final String text;
  const _Label(this.text);
  @override Widget build(BuildContext context) => Text(text, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppTheme.textSub, letterSpacing: 0.5));
}

class _QRow extends StatelessWidget {
  final String label, value;
  final Color? valueColor;
  const _QRow(this.label, this.value, {this.valueColor});
  @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 6),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(label, style: const TextStyle(color: Colors.white60, fontSize: 12)),
      Text(value, style: TextStyle(color: valueColor ?? Colors.white, fontWeight: FontWeight.w700, fontSize: 12)),
    ]));
}

// ── Product Picker ───────────────────────────────────────────────
class _ProductPickerSheet extends StatelessWidget {
  final List products;
  const _ProductPickerSheet({required this.products});

  @override
  Widget build(BuildContext context) => Container(
    height: MediaQuery.of(context).size.height * 0.78,
    decoration: const BoxDecoration(color: AppTheme.surface, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    child: Column(children: [
      Center(child: Container(margin: const EdgeInsets.only(top: 12), width: 40, height: 4, decoration: BoxDecoration(color: AppTheme.border, borderRadius: BorderRadius.circular(2)))),
      const Padding(padding: EdgeInsets.all(16), child: Text('🔧 Choose Equipment', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppTheme.dark))),
      const Divider(height: 1, color: AppTheme.border),
      Expanded(child: GridView.builder(
        padding: const EdgeInsets.all(14),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 0.82, mainAxisSpacing: 12, crossAxisSpacing: 12),
        itemCount: products.length,
        itemBuilder: (_, i) {
          final p = products[i];
          if ((int.tryParse(p['stock'].toString()) ?? 0) <= 0) return const SizedBox.shrink();
          return GestureDetector(
            onTap: () => Navigator.pop(context, p as Map),
            child: Container(
              decoration: BoxDecoration(color: AppTheme.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppTheme.border),
                  boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 6)]),
              clipBehavior: Clip.antiAlias,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Expanded(child: Container(color: AppTheme.bg, width: double.infinity,
                  child: p['image'] != null && p['image'].toString().isNotEmpty
                      ? Image.network('${ApiService.baseUrl.replaceAll('/api/api.php', '')}/${p['image']}', fit: BoxFit.cover, width: double.infinity,
                          errorBuilder: (_, __, ___) => const Icon(Icons.build_outlined, size: 32, color: AppTheme.textMuted))
                      : const Icon(Icons.build_outlined, size: 32, color: AppTheme.textMuted))),
                Padding(padding: const EdgeInsets.all(10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(p['name'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12, color: AppTheme.dark), maxLines: 2, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 4),
                  Text(formatCurrency(p['price']), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13, color: AppTheme.primary)),
                  Text('${p['stock']} in stock', style: const TextStyle(fontSize: 10, color: AppTheme.textMuted)),
                ])),
              ]),
            ),
          );
        },
      )),
    ]),
  );
}

// ── Status Sheet ─────────────────────────────────────────────────
class _StatusSheet extends StatefulWidget {
  final Map order;
  final String selected;
  final Function(String) onStatusChanged;
  final Function(String) onPaymentChanged;
  const _StatusSheet({required this.order, required this.selected, required this.onStatusChanged, required this.onPaymentChanged});
  @override State<_StatusSheet> createState() => _StatusSheetState();
}

class _StatusSheetState extends State<_StatusSheet> {
  late String _selected;
  String _payment = 'Cash';
  static const statuses = ['Pending', 'Fabricating', 'Quality Check', 'Delivered', 'Repair'];

  @override void initState() { super.initState(); _selected = widget.selected; }

  @override
  Widget build(BuildContext context) => Container(
    decoration: const BoxDecoration(color: AppTheme.surface, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Center(child: Container(margin: const EdgeInsets.only(top: 12), width: 40, height: 4, decoration: BoxDecoration(color: AppTheme.border, borderRadius: BorderRadius.circular(2)))),
      Padding(padding: const EdgeInsets.fromLTRB(20, 16, 8, 0), child: Row(children: [
        const Text('Update Status', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppTheme.dark)),
        const Spacer(),
        IconButton(icon: const Icon(Icons.close, color: AppTheme.textMuted), onPressed: () => Navigator.pop(context, false)),
      ])),
      const Divider(height: 1, color: AppTheme.border),
      Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: AppTheme.bg, borderRadius: BorderRadius.circular(12)),
          child: Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(widget.order['pname'] ?? '', style: const TextStyle(fontWeight: FontWeight.w700, color: AppTheme.dark)),
              Text('${widget.order['customer_name'] ?? 'Walk-in'} · ${widget.order['quantity']} unit${widget.order['quantity'] == 1 ? '' : 's'}',
                  style: const TextStyle(fontSize: 12, color: AppTheme.textSub)),
            ])),
            Text(formatCurrency(widget.order['cost']), style: const TextStyle(fontWeight: FontWeight.w800, color: AppTheme.primary, fontSize: 16)),
          ])),
        const SizedBox(height: 16),
        const _Label('SELECT STATUS'),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: statuses.map((s) => GestureDetector(
          onTap: () => setState(() { _selected = s; widget.onStatusChanged(s); }),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: _selected == s ? AppTheme.primary : AppTheme.bg,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _selected == s ? AppTheme.primary : AppTheme.border),
            ),
            child: Text(s, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13,
                color: _selected == s ? AppTheme.dark : AppTheme.textSub)),
          ),
        )).toList()),

        if (_selected == 'Delivered') ...[
          const SizedBox(height: 16),
          const _Label('PAYMENT METHOD'),
          const SizedBox(height: 8),
          Row(children: [
            _PayBtn('💵', 'Cash', _payment == 'Cash', () => setState(() { _payment = 'Cash'; widget.onPaymentChanged('Cash'); })),
            const SizedBox(width: 8),
            _PayBtn('📱', 'GCash', _payment == 'GCash', () => setState(() { _payment = 'GCash'; widget.onPaymentChanged('GCash'); })),
            const SizedBox(width: 8),
            _PayBtn('💳', 'Credit Card', _payment == 'Credit Card', () => setState(() { _payment = 'Credit Card'; widget.onPaymentChanged('Credit Card'); })),
          ]),
        ],
        const SizedBox(height: 20),
        SizedBox(height: 48, child: ElevatedButton(
          onPressed: () => Navigator.pop(context, true),
          child: const Text('Confirm Update', style: TextStyle(fontWeight: FontWeight.w800)),
        )),
        const SizedBox(height: 8),
      ])),
    ]),
  );
}

class _PayBtn extends StatelessWidget {
  final String emoji, label;
  final bool active;
  final VoidCallback onTap;
  const _PayBtn(this.emoji, this.label, this.active, this.onTap);
  @override Widget build(BuildContext context) => Expanded(child: GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: active ? const Color(0xFFFFF8EC) : AppTheme.bg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: active ? AppTheme.primary : AppTheme.border, width: active ? 2 : 1),
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(emoji, style: const TextStyle(fontSize: 24)),
        const SizedBox(height: 4),
        Text(label, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: active ? AppTheme.dark : AppTheme.textSub), textAlign: TextAlign.center),
      ]),
    ),
  ));
}
