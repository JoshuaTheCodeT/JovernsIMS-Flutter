import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static const Color primary    = Color(0xFFD4880A);
  static const Color primaryDark= Color(0xFFB8720A);
  static const Color dark       = Color(0xFF1E2640);
  static const Color dark2      = Color(0xFF2E3A5C);
  static const Color steel      = Color(0xFF4D9DE0);
  static const Color mint       = Color(0xFF3ECF8E);
  static const Color rose       = Color(0xFFC84040);
  static const Color bg         = Color(0xFFF0F3FA);
  static const Color surface    = Color(0xFFFFFFFF);
  static const Color cardBg     = Color(0xFFF9FAFD);
  static const Color border     = Color(0xFFD6DDED);
  static const Color textMuted  = Color(0xFF8A9DB8);
  static const Color textSub    = Color(0xFF5A6A88);

  static ThemeData get theme => ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: primary,
      brightness: Brightness.light,
      primary: primary,
      secondary: dark,
      surface: surface,
    ),
    scaffoldBackgroundColor: bg,
    textTheme: GoogleFonts.dmSansTextTheme().copyWith(
      displayLarge: GoogleFonts.syne(fontWeight: FontWeight.w800, color: dark),
      titleLarge: GoogleFonts.syne(fontWeight: FontWeight.w700, color: dark, fontSize: 18),
      titleMedium: GoogleFonts.dmSans(fontWeight: FontWeight.w700, color: dark, fontSize: 15),
      bodyLarge: GoogleFonts.dmSans(color: dark, fontSize: 14),
      bodyMedium: GoogleFonts.dmSans(color: textSub, fontSize: 13),
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: surface,
      foregroundColor: dark,
      elevation: 0,
      shadowColor: Colors.transparent,
      titleTextStyle: GoogleFonts.syne(fontWeight: FontWeight.w800, color: dark, fontSize: 18),
    ),
    cardTheme: CardThemeData(
      elevation: 0,
      color: surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: border, width: 1),
      ),
    ),

    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: surface,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: border)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: border)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: primary, width: 2)),
      errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: rose, width: 1.5)),
      labelStyle: GoogleFonts.dmSans(color: textSub, fontWeight: FontWeight.w600, fontSize: 13),
      hintStyle: GoogleFonts.dmSans(color: textMuted, fontSize: 13),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: primary,
        foregroundColor: dark,
        textStyle: GoogleFonts.dmSans(fontWeight: FontWeight.w700, fontSize: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
        elevation: 0,
      ),
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: surface,
      selectedItemColor: primary,
      unselectedItemColor: textMuted,
      elevation: 8,
      type: BottomNavigationBarType.fixed,
    ),
  );
}

class StatCard extends StatelessWidget {
  final String label, value, hint;
  final Color color;
  final IconData icon;
  const StatCard({super.key, required this.label, required this.value, required this.hint, required this.color, required this.icon});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: AppTheme.surface,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: AppTheme.border),
      boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 8, offset: const Offset(0, 2))],
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(
        width: 34, height: 34,
        decoration: BoxDecoration(color: color.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(9)),
        child: Icon(icon, color: color, size: 17),
      ),
      const SizedBox(height: 8),
      Text(label, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: AppTheme.textSub, letterSpacing: 0.4)),
      const SizedBox(height: 3),
      Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppTheme.dark)),
      const SizedBox(height: 2),
      Text(hint, style: const TextStyle(fontSize: 10, color: AppTheme.textMuted)),
    ]),
  );
}

class SectionHeader extends StatelessWidget {
  final String title;
  final Widget? trailing;
  const SectionHeader({super.key, required this.title, this.trailing});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(0, 16, 0, 8),
    child: Row(children: [
      Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: AppTheme.dark)),
      const Spacer(),
      if (trailing != null) trailing!,
    ]),
  );
}

Widget statusBadge(String status) {
  final map = {
    'Pending':       [const Color(0xFFFFF3CD), const Color(0xFFD4880A)],
    'Fabricating':   [const Color(0xFFDCEEFB), AppTheme.steel],
    'Quality Check': [const Color(0xFFDCEEFB), AppTheme.steel],
    'Delivered':     [const Color(0xFFD4EDDA), AppTheme.mint],
    'Repair':        [const Color(0xFFF8D7DA), AppTheme.rose],
  };
  final colors = map[status] ?? [AppTheme.bg, AppTheme.textMuted];
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(color: colors[0] as Color, borderRadius: BorderRadius.circular(20)),
    child: Text(status, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: colors[1] as Color)),
  );
}

String formatCurrency(dynamic v) {
  final d = double.tryParse(v.toString()) ?? 0;
  return '₱${d.toStringAsFixed(2).replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+(?!\d))'), (m) => '${m[1]},')}';
}
