import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'services/api_service.dart';
import 'theme/app_theme.dart';
import 'screens/login_screen.dart';
import 'screens/main_shell.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
  ));
  await ApiService.loadToken();
  runApp(const JovernsApp());
}

class JovernsApp extends StatelessWidget {
  const JovernsApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: "Jovern's IMS",
    theme: AppTheme.theme,
    debugShowCheckedModeBanner: false,
    home: ApiService.isLoggedIn ? const MainShell() : const LoginScreen(),
  );
}
