import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  // ⚠️ Change this to your server IP — e.g. http://192.168.1.5/ims/api/api.php
  static const String baseUrl = 'http://192.168.1.5/ims/api/api.php';

  static String? _token;
  static String? _role;
  static String? _username;

  static Future<void> loadToken() async {
    final prefs = await SharedPreferences.getInstance();
    _token    = prefs.getString('token');
    _role     = prefs.getString('role');
    _username = prefs.getString('username');
  }

  static Future<void> saveToken(String token, String role, String username) async {
    _token = token; _role = role; _username = username;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('token', token);
    await prefs.setString('role', role);
    await prefs.setString('username', username);
  }

  static Future<void> clearToken() async {
    _token = null; _role = null; _username = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
    await prefs.remove('role');
    await prefs.remove('username');
  }

  static String? get token    => _token;
  static String? get role     => _role;
  static String? get username => _username;
  static bool    get isAdmin  => _role == 'admin';
  static bool    get isLoggedIn => _token != null;

  static Map<String, String> get _headers => {
    'Content-Type': 'application/json',
    if (_token != null) 'Authorization': 'Bearer $_token',
  };

  static Uri _url(String path, [Map<String, String>? params]) {
    if (params == null) return Uri.parse('$baseUrl?path=$path');
    final allParams = <String, String>{'path': path, ...params};
    return Uri.parse(baseUrl).replace(queryParameters: allParams);
  }

  static Future<Map<String, dynamic>> _handle(http.Response res) async {
    final body = jsonDecode(res.body);
    if (res.statusCode == 401) throw ApiException('Session expired. Please log in again.');
    if (body['success'] != true) throw ApiException(body['error'] ?? 'Unknown error');
    return body;
  }

  // AUTH
  static Future<Map<String, dynamic>> login(String u, String p) async {
    final res = await http.post(_url('login'), headers: _headers,
        body: jsonEncode({'username': u, 'password': p}));
    return _handle(res);
  }

  static Future<void> logout() async {
    try { await http.post(_url('logout'), headers: _headers); } catch (_) {}
    await clearToken();
  }

  // DASHBOARD
  static Future<Map<String, dynamic>> getDashboard() async {
    final res = await http.get(_url('dashboard'), headers: _headers);
    final body = await _handle(res);
    return body['data'];
  }

  // CATEGORIES
  static Future<List> getCategories() async {
    final res = await http.get(_url('categories'), headers: _headers);
    final body = await _handle(res);
    return body['data'];
  }

  static Future<void> addCategory(String name, List mats) async {
    final res = await http.post(_url('categories'), headers: _headers,
        body: jsonEncode({'category_name': name, 'mats': mats}));
    await _handle(res);
  }

  static Future<void> updateCategory(int id, String name, List mats) async {
    final res = await http.put(_url('categories/$id'), headers: _headers,
        body: jsonEncode({'category_name': name, 'mats': mats}));
    await _handle(res);
  }

  static Future<void> deleteCategory(int id) async {
    final res = await http.delete(_url('categories/$id'), headers: _headers);
    await _handle(res);
  }

  // MATERIALS
  static Future<List> getMaterials() async {
    final res = await http.get(_url('materials'), headers: _headers);
    final body = await _handle(res);
    return body['data'];
  }

  static Future<void> addMaterial(Map<String, dynamic> data) async {
    final res = await http.post(_url('materials'), headers: _headers, body: jsonEncode(data));
    await _handle(res);
  }

  static Future<void> updateMaterial(int id, Map<String, dynamic> data) async {
    final res = await http.put(_url('materials/$id'), headers: _headers, body: jsonEncode(data));
    await _handle(res);
  }

  static Future<void> deleteMaterial(int id) async {
    final res = await http.delete(_url('materials/$id'), headers: _headers);
    await _handle(res);
  }

  // PRODUCTS
  static Future<List> getProducts() async {
    final res = await http.get(_url('products'), headers: _headers);
    final body = await _handle(res);
    return body['data'];
  }

  static Future<Map<String, dynamic>> getProduct(int id) async {
    final res = await http.get(_url('products/$id'), headers: _headers);
    final body = await _handle(res);
    return body['data'];
  }

  static Future<Map<String, dynamic>> addProduct(Map<String, dynamic> data) async {
    final res = await http.post(_url('products'), headers: _headers, body: jsonEncode(data));
    final body = await _handle(res);
    return body['data'];
  }

  static Future<Map<String, dynamic>> updateProduct(int id, Map<String, dynamic> data) async {
    final res = await http.put(_url('products/$id'), headers: _headers, body: jsonEncode(data));
    final body = await _handle(res);
    return body['data'];
  }

  static Future<void> deleteProduct(int id) async {
    final res = await http.delete(_url('products/$id'), headers: _headers);
    await _handle(res);
  }

  // CUSTOMERS
  static Future<List> getCustomers() async {
    final res = await http.get(_url('customers'), headers: _headers);
    final body = await _handle(res);
    return body['data'];
  }

  static Future<void> addCustomer(Map<String, dynamic> data) async {
    final res = await http.post(_url('customers'), headers: _headers, body: jsonEncode(data));
    await _handle(res);
  }

  static Future<void> updateCustomer(int id, Map<String, dynamic> data) async {
    final res = await http.put(_url('customers/$id'), headers: _headers, body: jsonEncode(data));
    await _handle(res);
  }

  static Future<void> deleteCustomer(int id) async {
    final res = await http.delete(_url('customers/$id'), headers: _headers);
    await _handle(res);
  }

  // PURCHASES
  static Future<List> getPurchases({bool all = false}) async {
    final params = all ? {'all': '1'} : <String, String>{};
    final res = await http.get(_url('purchases', params), headers: _headers);
    final body = await _handle(res);
    return body['data'];
  }

  static Future<Map<String, dynamic>> addPurchase(Map<String, dynamic> data) async {
    final res = await http.post(_url('purchases'), headers: _headers, body: jsonEncode(data));
    final body = await _handle(res);
    return body['data'];
  }

  static Future<void> updatePurchaseStatus(int id, String status, String paymentMethod) async {
    final res = await http.put(_url('purchases/$id'), headers: _headers,
        body: jsonEncode({'status': status, 'payment_method': paymentMethod}));
    await _handle(res);
  }

  // QUOTATION
  static Future<Map<String, dynamic>> getQuotation(int productId, int qty, double discount) async {
    final res = await http.post(_url('quotation'), headers: _headers,
        body: jsonEncode({'product_id': productId, 'quantity': qty, 'discount': discount}));
    final body = await _handle(res);
    return body['data'];
  }

  // REPORTS
  static Future<Map<String, dynamic>> getReports() async {
    final res = await http.get(_url('reports'), headers: _headers);
    final body = await _handle(res);
    return body['data'];
  }

  // USERS
  static Future<List> getUsers() async {
    final res = await http.get(_url('users'), headers: _headers);
    final body = await _handle(res);
    return body['data'];
  }

  static Future<void> addUser(String username, String password, String role) async {
    final res = await http.post(_url('users'), headers: _headers,
        body: jsonEncode({'username': username, 'password': password, 'role': role}));
    await _handle(res);
  }

  static Future<void> updateUser(int id, String username, String role, {String? password}) async {
    final body = <String, dynamic>{'username': username, 'role': role};
    if (password != null && password.isNotEmpty) body['password'] = password;
    final res = await http.put(_url('users/$id'), headers: _headers, body: jsonEncode(body));
    await _handle(res);
  }

  static Future<void> deleteUser(int id) async {
    final res = await http.delete(_url('users/$id'), headers: _headers);
    await _handle(res);
  }

  static Future<void> updateUser(int id, String username, String role, {String? password}) async {
    final body = <String, dynamic>{'username': username, 'role': role};
    if (password != null && password.isNotEmpty) body['password'] = password;
    final res = await http.put(_url('users/$id'), headers: _headers, body: jsonEncode(body));
    await _handle(res);
  }

  static Future<void> deleteUser(int id) async {
    final res = await http.delete(_url('users/$id'), headers: _headers);
    await _handle(res);
  }

}

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override String toString() => message;
}
