package com.example.joverns_ims_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
